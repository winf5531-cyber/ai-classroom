# AI 학습실

중·고등학생이 Chrome에서 직접 모은 문장이나 사진으로 분류 모델을 학습하는 LearningML 기반 한국어 편집기입니다.

## 수업에서 열기

- 이 프로젝트 폴더에 배포본 `dist`가 있는 Windows 컴퓨터에서는 `start-classroom.cmd`를 두 번 클릭하세요. 브라우저에 학습실이 열립니다. 창이 열리지 않으면 실행 창에 표시된 주소를 Chrome에 붙여 넣으세요. 실행 창을 닫으면 서버도 종료됩니다.
- 로컬 주소는 실행한 컴퓨터에서만 열립니다. 여러 크롬북을 사용하는 수업에서는 아래 방법으로 학교가 승인한 정적 호스팅에 배포한 뒤 같은 HTTPS 주소를 학생들에게 나눠 주세요. 학생 계정이나 설치 프로그램은 필요하지 않습니다.
- **텍스트 분류 → 그룹 추가 → 문장 추가 → AI 모델 학습하기 → 분류하기** 순서로 진행하세요. 그룹 두 개 이상, 그룹마다 서로 다른 예시 세 개 이상이 필요합니다. 파일 메뉴의 **예제 데이터 → 한국어 감정**으로 먼저 연습할 수도 있습니다.
- 이미지 분류에서는 파일 선택이나 카메라로 자료를 모으고, 학습에 쓰지 않은 새 사진으로 결과를 확인하세요. 학습 도움말 메뉴의 [AI 학습실 사용 안내](public/guide.html)에 활동별 절차가 있습니다.

## 데이터와 저장

학습 자료와 모델 계산은 기본 설정에서 학생의 브라우저에 머무릅니다. 새로고침하거나 탭을 닫으면 편집 중이던 그룹과 예시가 사라집니다. 파일 메뉴의 **학습 데이터 저장**을 선택하세요. JSON 파일을 **학습 데이터 불러오기**로 열면 텍스트·이미지 예시와 그룹이 복원됩니다. 불러온 뒤 다시 학습하세요. 원본의 모델 내보내기(.mdl)도 제공됩니다. 한국어 특징을 사용하는 모델을 처리하려면 같은 인코더가 필요합니다.

이미지 인식용 MobileNet V1과 화면 스타일은 같은 사이트에서 제공합니다. 소리 활동에서 처음 사용하는 공통 음성 모델은 외부에서 내려받으므로 인터넷과 마이크 권한이 필요합니다. Scratch 연결은 동일 출처에 호환 설치가 있고 운영자가 URL_SCRATCH를 지정한 경우에 사용합니다.

## 개발 환경과 실행

프로젝트의 패키지 관리자는 Bun 1.3.6입니다. 개발 컴퓨터에는 Node.js 22 이상과 Bun 1.3.6을 설치하세요. [Node.js 다운로드](https://nodejs.org/en/download) · [Bun 설치](https://bun.com/docs/installation)

```sh
bun install --frozen-lockfile
bun run dev
```

터미널에 표시되는 Local 주소를 여세요. 두 실행 환경이 설치된 Windows에서는 프로젝트 폴더에서 위 명령을 실행하면 됩니다. 이 작업 폴더의 Windows용 Bun은 `.tools/bun-windows-x64/bun.exe`에도 있습니다. 소스 ZIP으로 새로 설치할 때는 공식 Bun을 사용하세요.

```sh
bun run test
bun run build
bun run preview
```

빌드 명령은 웹에서 제공할 모델, 안내문, 라이선스 고지와 현재 수정 소스 ZIP을 조립하고 Vite로 `dist/`를 만듭니다. HTML 파일을 직접 여는 대신 HTTP 서버로 실행하세요. 설치된 Chrome으로 브라우저 테스트를 실행하는 PowerShell 예시는 다음과 같습니다.

```powershell
$env:PW_CHANNEL = "chrome"
bun run test:e2e --workers=1
```

기본 Playwright Chromium을 사용할 때는 `bunx playwright install chromium`으로 테스트 브라우저를 설치하고 `PW_CHANNEL` 없이 실행하세요. 브라우저 테스트는 먼저 생성한 배포본을 사용합니다.

## GitHub Pages에 배포하기

1. 학교가 승인한 **자신의 GitHub 저장소**에 소스코드, `bun.lock`, `patches/`, `.github/workflows/deploy.yml`을 포함해 올리세요. 다운로드한 수정 소스 ZIP을 풀어 시작할 수도 있습니다. 개인 개발 도구와 빌드 결과는 올릴 필요가 없습니다.
2. 그 저장소의 **Settings → Pages → Build and deployment → Source**에서 **GitHub Actions**를 선택하세요.
3. **Actions → AI 학습실 Pages 배포 → Run workflow**에서 배포할 브랜치를 선택하세요. 이 수동 실행이 테스트, 빌드, Pages 배포를 차례로 수행합니다.
4. 완료된 실행의 **github-pages** 링크에서 홈, 모델 학습, 하단의 수정 소스 다운로드를 확인하세요. 이 주소가 학생들에게 나눠 줄 수업 주소입니다.

Pages 설정에서 받은 경로를 빌드의 BASE_URL로 전달하므로 저장소 이름이 달라도 작동합니다. 다른 정적 서버의 하위 경로에 올릴 때는 빌드 전에 BASE_URL을 실제 경로(예: `/classroom/`)로 설정하고 `dist/`의 내용 전체를 게시하세요.

## 수정과 관리

| 수정할 항목 | 파일 |
| --- | --- |
| 서비스 이름과 로고 | `src/brand.js`, `public/images/classroom-mark.svg`. 이름은 VITE_SITE_NAME으로 설정할 수도 있습니다. |
| 학생 화면과 파일 처리 | `src/components/`, `src/utils/project-file.js` |
| 한국어 번역 | `lit-localize.json`, `xliff/ko.xlf`, `src/i18n/ko.js` |
| 알고리즘 도움말 | `src/components/model-editor/algorithm-help/`, `algorithm-theory/` |
| 텍스트 특징과 원본 알고리즘 연결 | `src/services/korean-text.js`, `src/services/lml-algorithms-bridge.js` |
| 음성 모델 로딩과 이미지 오류 처리 | `patches/lml-algorithms@1.0.38.patch` |
| 사이트에 포함할 자료와 소스 ZIP | `scripts/prepare-site.mjs` |
| 수업용 예제와 사용 안내 | `examples/datasets/한국어-감정.json`, `public/guide.html` |

문구를 바꿀 때는 `bun run translate-extract`로 XLIFF를 갱신하고 번역한 뒤 `bun run translate-build`로 런타임 번역을 생성하세요. 변경 파일과 주요 동작 차이는 [변경 이력](CHANGELOG.md)에 정리되어 있습니다.

## 한국어 분류 방식과 한계

원본의 텍스트 특징 추출기는 영문 소문자와 숫자 위주로 단어를 구성하므로 ‘환경을 보호한다.’에서 한글 특징을 얻지 못했습니다. 한국어가 포함된 학습 자료에는 NFC 정규화 후 어절 전체와 이웃한 두세 음절을 함께 사용합니다. ‘환경을 보호한다.’와 ‘환경보호를 실천한다.’에서 ‘환경’, ‘보호’를 함께 활용하고, ‘보호하지 않는다.’에서 ‘하지’, ‘않는’ 같은 차이를 학습할 수 있습니다. 문장부호와 줄바꿈 경계를 넘는 음절 특징은 만들지 않습니다. 형태소 분석기나 외부 언어 모델은 사용하지 않습니다. 한글이 없는 학습 자료는 원본 인코더를 사용합니다.

문맥이나 동의어를 이해하는 언어 모델은 아닙니다. 겹치는 표현이 많거나 학습 자료가 적으면 의미가 반대인 문장도 비슷하게 분류할 수 있습니다. 겹치는 특징이 없으면 학생에게 추가 예시를 요청합니다. 그룹별 예측 점수는 100점 기준으로 표시하며 실제 정답률을 뜻하지 않습니다.

## 문제가 생겼을 때

- 학습 버튼에서 안내가 뜨면 각 그룹에 중복되지 않는 예시가 세 개 이상 있는지 확인하세요.
- 이미지를 불러오지 못하면 PNG나 JPEG 파일로 다시 시도하세요. 학교 서버에서 모델 경로의 JSON과 가중치 파일 다섯 개가 모두 열리는지 확인하세요.
- 카메라가 열리지 않으면 사이트 권한, 다른 프로그램의 카메라 사용, HTTPS 주소를 확인하세요. 이미지 파일 업로드로도 활동할 수 있습니다.
- 업데이트 후 화면이 비면 BASE_URL과 실제 게시 경로가 일치하는지 확인하세요. assets, images, models, notices, source.zip을 포함한 배포본 전체가 함께 있어야 합니다.
- 공용 기기에서는 다운로드한 JSON에 원문이나 사진이 그대로 들어 있다는 점을 고려해 자료를 관리하세요.

## 출처와 라이선스

이 사이트는 LearningML 오픈소스를 기반으로 제작한 비공식 한국어 교육용 서비스입니다. 원저작자는 Juan David Rodríguez García이며 편집기는 GNU AGPL-3.0, lml-algorithms 1.0.38은 GPL-3.0-or-later로 표시되어 있습니다. [원본 편집기](https://github.com/LearningML-Education/lml-editor) · [원본 알고리즘](https://github.com/LearningML-Education/lml-algorithms)

배포본의 라이선스 화면에서 전문과 라이브러리별 고지를 볼 수 있고, 하단에서 해당 빌드의 수정 소스와 빌드 스크립트를 내려받을 수 있습니다. 재배포할 때 이 파일들과 소스 다운로드 링크를 함께 유지하세요. 원본 공식 로고와 홍보 이미지는 한국어 사이트의 배포 자산에서 제외했습니다. 색과 도형의 학습·시험용 PNG는 이 프로젝트의 scripts/generate-shape-examples.mjs로 직접 생성합니다. 그림과 생성기는 GNU AGPL 3.0으로 배포하며, MobileNet V1은 Google 모델 배포 페이지와 Apache 2.0 전문을 라이선스 화면에 안내합니다.
