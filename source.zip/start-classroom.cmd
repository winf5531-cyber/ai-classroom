@echo off
setlocal
cd /d "%~dp0"
if exist ".tools\bun-windows-x64\bun.exe" (
  ".tools\bun-windows-x64\bun.exe" scripts\serve.mjs --open
) else (
  where node >nul 2>nul
  if errorlevel 1 (
    bun scripts\serve.mjs --open
  ) else (
    node scripts\serve.mjs --open
  )
)
if errorlevel 1 pause
