import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';

// Use the same ZIP implementation and version pinned by the ML library.
const require = createRequire(import.meta.url);
const JSZip = createRequire(require.resolve('lml-algorithms/package.json'))('jszip');
const site = '.tools/static';
const notices = path.join(site, 'notices');
await fs.mkdir(notices, { recursive: true });
const zip = new JSZip();
async function addTree(source, target = source) {
  const stat = await fs.stat(source);
  if (stat.isDirectory()) {
    for (const entry of (await fs.readdir(source)).sort()) {
      await addTree(path.join(source, entry), path.posix.join(target, entry));
    }
  } else {
    zip.file(target, await fs.readFile(source));
  }
}
const names = ['src', 'examples', 'tests', 'scripts', 'legal', 'patches', 'xliff', '.github',
  'index.html', 'package.json', 'bun.lock', 'lit-localize.json', 'vite.config.js',
  'playwright.config.js', 'bunfig.toml', '.env.dist', '.gitignore', 'LICENSE', 'README.md',
  'CHANGELOG.md', 'AGENTS.md', 'start-classroom.cmd'];
for (const name of names) await addTree(name);
const mobileNetDirectory = 'models/imagenet_mobilenet_v1_100_224_classification_1';
const modelFiles = new Set(await fs.readdir(path.join('public', mobileNetDirectory)));
const stagedModel = path.join(site, mobileNetDirectory);
await fs.mkdir(stagedModel, { recursive: true });
for (const name of await fs.readdir(stagedModel)) {
  if (!modelFiles.has(name)) await fs.unlink(path.join(stagedModel, name));
}
const staticFiles = ['guide.html', 'guide.css', 'licenses.html', 'classroom-doc.css',
  mobileNetDirectory, 'models/movenet-lightning',
  ...(await fs.readdir('public/images')).filter(n => n.startsWith('classroom-')).map(n => 'images/' + n)];
for (const file of staticFiles) {
  await addTree('public/' + file);
  await fs.mkdir(path.dirname(path.join(site, file)), { recursive: true });
  await fs.cp('public/' + file, path.join(site, file), { recursive: true });
}
await fs.copyFile('LICENSE', path.join(notices, 'AGPL-3.0.txt'));
await fs.copyFile('legal/GPL-3.0.txt', path.join(notices, 'GPL-3.0.txt'));
await fs.copyFile('legal/Apache-2.0.txt', path.join(notices, 'Apache-2.0.txt'));
const seen = new Set();
const records = [];
async function collect(pkgName, parent = '.') {
  let folder = path.join(parent, 'node_modules', pkgName);
  while (true) {
    try { await fs.access(path.join(folder, 'package.json')); break; } catch {
      const next = path.dirname(parent);
      if (next === parent) throw new Error('Missing dependency: ' + pkgName);
      parent = next;
      folder = path.join(parent, 'node_modules', pkgName);
    }
  }
  const pkg = JSON.parse(await fs.readFile(path.join(folder, 'package.json'), 'utf8'));
  const id = pkg.name + '@' + pkg.version;
  if (seen.has(id)) return;
  seen.add(id);
  const notices = [];
  for (const name of (await fs.readdir(folder)).filter(n => /^(license|licence|notice|copying)(\.|-|$)/i.test(n))) {
    if ((await fs.stat(path.join(folder, name))).isFile()) notices.push(await fs.readFile(path.join(folder, name), 'utf8'));
  }
  records.push([id, typeof pkg.license === 'string' ? pkg.license : JSON.stringify(pkg.license || pkg.licenses || ''), ...notices].join('\n'));
  for (const dep of Object.keys(pkg.dependencies || {})) await collect(dep, folder);
}
const rootPkg = JSON.parse(await fs.readFile('package.json', 'utf8'));
for (const dep of Object.keys(rootPkg.dependencies)) await collect(dep);
const noticeText = records.sort().join('\n\n----------------------------------------\n\n');
await fs.writeFile(path.join(notices, 'third-party.txt'), noticeText);
zip.file('legal/third-party.txt', noticeText);
await addTree('node_modules/lml-algorithms/src', 'vendor/lml-algorithms/src');
await addTree('node_modules/lml-algorithms/package.json', 'vendor/lml-algorithms/package.json');
await fs.writeFile(path.join(site, 'source.zip'), await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 3 }}));
