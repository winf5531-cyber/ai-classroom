import http from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = fileURLToPath(new URL('../dist/', import.meta.url));
if (!existsSync(path.join(root, 'index.html'))) {
  console.error('배포 파일을 찾을 수 없습니다. 프로젝트 폴더에서 bun run build를 실행하세요.');
  process.exit(1);
}
const types = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.zip': 'application/zip' };
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const name = decodeURIComponent(url.pathname);
    const file = path.resolve(root, '.' + (name === '/' ? '/index.html' : name));
    if (!file.startsWith(path.resolve(root) + path.sep) || !(await stat(file)).isFile()) throw new Error();
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    createReadStream(file).on('error', () => res.destroy()).pipe(res);
  } catch {
    res.writeHead(404);
    res.end();
  }
});
server.on('error', err => { console.error(err.message); process.exitCode = 1; });
server.listen(0, '127.0.0.1', () => {
  const url = 'http://127.0.0.1:' + server.address().port + '/';
  console.log('AI 학습실  ' + url + '\n이 창을 닫으면 학습실이 종료됩니다.');
  if (process.argv.includes('--open') && process.platform === 'win32') spawn('explorer.exe', [url], { windowsHide: true });
});
