// Generates the classroom illustrations from geometric formulas and flat RGB colors.
// No photographs, fonts, copied drawings, or external assets are used.
// The generated images and the generator are distributed with the project under GNU AGPL v3.
import { mkdir, writeFile } from 'node:fs/promises';
import { deflateSync } from 'node:zlib';

const root = new URL('../', import.meta.url);
const fixtures = new URL('tests/fixtures/shapes/', root);
const size = 192;
const background = [251, 249, 242];
const groups = [
  { file: 'circle', label: '빨간 원', rgb: [213, 51, 58], contains: (x, y) => x*x + y*y <= 1 },
  { file: 'square', label: '파란 네모', rgb: [37, 91, 195], contains: (x, y) => Math.abs(x) <= 0.9 && Math.abs(y) <= 0.9 },
  { file: 'triangle', label: '초록 세모', rgb: [26, 140, 80], contains: (x, y) => y >= -1 && y <= 1 && Math.abs(x) <= (y + 1) / 2 }
];

// Shared positions, sizes, rotations (in degrees), and brightness offsets ensure
// each group has the same range of variation. The test variant is never used for training.
const trainVariants = [
  [94, 95, 66, 0, 0], [102, 92, 59, 7, -9], [88, 93, 63, -8, 10], [98, 100, 70, 2, -5],
  [93, 104, 62, -5, 6], [87, 99, 58, 10, -3], [105, 96, 65, -3, 4], [96, 88, 69, 5, -7]
];
const testVariant = [97, 97, 64, -2, 2];

function pngChunk(type, payload) {
  const bytes = Buffer.concat([Buffer.from(type, 'ascii'), payload]);
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) {
      crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
    }
  }
  const length = Buffer.alloc(4);
  const checksum = Buffer.alloc(4);
  length.writeUInt32BE(payload.length);
  checksum.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
  return Buffer.concat([length, bytes, checksum]);
}

function drawShape(group, [cx, cy, radius, degrees, brightness]) {
  const rotation = degrees * Math.PI / 180;
  const cos = Math.cos(rotation), sin = Math.sin(rotation);
  const stride = 1 + size * 3; // First byte of each RGB scanline is the PNG filter type (0).
  const scanlines = Buffer.alloc(stride * size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let coverage = 0;
      for (const dy of [0.25, 0.75]) {
        for (const dx of [0.25, 0.75]) {
          const u = (x + dx - cx) / radius, v = (y + dy - cy) / radius;
          if (group.contains(u * cos + v * sin, v * cos - u * sin)) coverage += 0.25;
        }
      }
      const offset = stride * y + 1 + x * 3;
      for (let c = 0; c < 3; c++) {
        scanlines[offset + c] = Math.round(background[c] * (1 - coverage) + (group.rgb[c] + brightness) * coverage);
      }
    }
  }
  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0);
  header.writeUInt32BE(size, 4);
  header[8] = 8;
  header[9] = 2; // Truecolor RGB
  return Buffer.concat([
    Buffer.from('89504e470d0a1a0a', 'hex'), pngChunk('IHDR', header),
    pngChunk('IDAT', deflateSync(scanlines, { level: 9 })), pngChunk('IEND', Buffer.alloc(0))
  ]);
}

await mkdir(new URL('train/', fixtures), { recursive: true });
await mkdir(new URL('test/', fixtures), { recursive: true });
const dataset = { type: 'image', data: {} };
for (const group of groups) {
  const samples = [];
  for (const [index, variant] of trainVariants.entries()) {
    const png = drawShape(group, variant);
    const number = String(index + 1).padStart(2, '0');
    await writeFile(new URL('train/' + group.file + '-' + number + '.png', fixtures), png);
    samples.push('data:image/png;base64,' + png.toString('base64'));
  }
  dataset.data[group.label] = samples;
  await writeFile(new URL('test/' + group.file + '.png', fixtures), drawShape(group, testVariant));
}
await writeFile(new URL('examples/datasets/색과-도형.json', root), JSON.stringify(dataset, null, 2) + '\n');
