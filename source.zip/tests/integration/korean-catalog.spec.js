import { expect, test } from 'bun:test';
import { fileURLToPath } from 'node:url';
import { RuntimeLitLocalizer } from '@lit/localize-tools/lib/modes/runtime.js';
import { readConfigFileAndWriteSchema } from '@lit/localize-tools/lib/config.js';
import { templates } from '../../src/i18n/ko.js';

test('every extracted UI message has a Korean translation in the shipped catalog', () => {
  const path = fileURLToPath(new URL('../../lit-localize.json', import.meta.url));
  const localizer = new RuntimeLitLocalizer(readConfigFileAndWriteSchema(path));
  const { messages, errors } = localizer.extractSourceMessages();
  expect(errors).toHaveLength(0);
  const { translations } = localizer.readTranslationsSync();
  const expected = messages.map(message => message.name).sort();
  const korean = translations.get('ko');
  expect(korean.map(message => message.name).sort()).toEqual(expected);
  expect(Object.keys(templates).sort()).toEqual(expected);
  for (const { name, contents } of korean) {
    const translatedText = contents.filter(part => typeof part === 'string').join('');
    expect(translatedText, name).toMatch(/[가-힣]/);
  }
}, 30000);
