import { expect, test } from 'bun:test';
import { bowEncoder as upstreamEncode, buildVocabulary as upstreamVocabulary } from 'lml-algorithms';
import { bowEncoder, buildVocabulary, KNN, setVocabulary } from '../../src/services/lml-algorithms-bridge.js';

test('original and adapted vocabularies round-trip without changing their feature columns', async () => {
  const sentence = '환경을 보호한다.';
  expect(upstreamVocabulary([sentence])).toEqual([]);
  const vocabulary = await buildVocabulary([sentence]);
  const encoded = await bowEncoder([sentence]);
  const originalCounts = encoded.arraySync();
  encoded.dispose();
  const existingVocabulary = ['caf', 'good', 'day'];
  setVocabulary(existingVocabulary);
  const legacy = await bowEncoder(['Café, good day!', sentence]);
  const reference = await upstreamEncode(['Café, good day!', sentence]);
  expect(legacy.arraySync()).toEqual(reference.arraySync());
  legacy.dispose();
  reference.dispose();
  setVocabulary(JSON.parse(JSON.stringify(vocabulary)));
  const restored = await bowEncoder([sentence.normalize('NFD')]);
  expect(restored.arraySync()).toEqual(originalCounts);
  restored.dispose();
});

test('LearningML KNN learns Korean classes and sorts scores for unseen sentences', async () => {
  const examples = new Map([
    ['긍정', ['오늘은 기분이 정말 좋다.', '친구와 즐거운 시간을 보냈다.', '시험 결과가 만족스럽다.', '나는 학교생활이 행복하다.', '좋은 소식을 들었다.']],
    ['부정', ['오늘은 기분이 나쁘다.', '친구와 다투어서 속상하다.', '시험 결과가 실망스럽다.', '학교생활이 너무 힘들다.', '좋지 않은 소식을 들었다.']],
  ]);
  await buildVocabulary(Array.from(examples.values()).flat());
  const features = new Map();
  for (const [label, texts] of examples) features.set(label, await bowEncoder(texts));
  const model = new KNN();
  model.setHyperParameters({ K: 1 });
  try {
    await model.train(features);
    for (const [sentence, label] of [['동생과 즐거운 시간을 보냈다.', '긍정'], ['결과가 너무 실망스럽다.', '부정']]) {
      const scores = await model.classify(await bowEncoder([sentence]));
      expect(scores.map(row => row[0]).sort()).toEqual(['긍정', '부정']);
      expect(scores[0][0]).toBe(label);
      expect(scores[0][1]).toBeGreaterThan(scores[1][1]);
    }
  } finally {
    model.model?.dispose();
    for (const tensor of features.values()) tensor.dispose();
  }
});
