import fs from 'node:fs/promises';
import path from 'node:path';
import { expect, test } from '@playwright/test';

for (const [section, title, filename] of [
  ['text', '한국어 감정', '한국어-감정.json'],
  ['image', '색과 도형', '색과-도형.json']
]) {
  test(`설명서에서 ${title} 예제를 내려받아 학습실에서 연다`, async ({ page }, info) => {
    await page.goto('guide.html');
    const link = page.getByRole('link', { name: `${title} 예제 내려받기 (JSON)`, exact: true });
    await expect(page.locator('article#' + section)).toContainText(title);
    if (section === 'text') {
      const intro = page.getByRole('link', { name: '한국어 감정 예제를 내려받아' });
      await expect(intro).toHaveAttribute('href', await link.getAttribute('href'));
      await expect(intro).toHaveAttribute('download', '');
    }
    const downloading = page.waitForEvent('download');
    await link.click();
    const download = await downloading;
    expect(download.suggestedFilename()).toBe(filename);
    const saved = info.outputPath(filename);
    await download.saveAs(saved);
    const source = await fs.readFile(path.join('examples', 'datasets', filename), 'utf8');
    expect(await fs.readFile(saved, 'utf8')).toBe(source);

    await page.getByRole('link', { name: '학습실로 돌아가기', exact: true }).click();
    const menu = page.locator('file-menu');
    await menu.getByRole('link', { name: '파일', exact: true }).click();
    const choosing = page.waitForEvent('filechooser');
    await menu.getByText('학습 데이터 불러오기', { exact: true }).click();
    await (await choosing).setFiles(saved);
    const { data } = JSON.parse(source);
    await expect(page.locator('dataset-manager')).toHaveCount(Object.keys(data).length);
    for (const [label, entries] of Object.entries(data)) {
      const group = page.locator('dataset-manager').filter({ has: page.getByText(label, { exact: true }) });
      if (section === 'image') {
        await expect(group.locator('img.image-item')).toHaveCount(entries.length);
      } else {
        for (const sentence of entries) await expect(group.getByText(sentence, { exact: true })).toBeVisible();
      }
    }
  });
}
