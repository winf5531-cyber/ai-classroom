import fs from 'node:fs/promises';
import path from 'node:path';
import { expect, test } from '@playwright/test';

for (const [section, title, filename] of [
  ['text', '한국어 감정', '한국어-감정.json'],
  ['image', '색과 도형', '색과-도형.json']
]) {
  test(`설명서 안내에 따라 ${title} 예제를 메뉴와 다운로드로 연다`, async ({ page }, info) => {
    await page.goto('guide.html');
    const article = page.locator('article#' + section);
    const link = article.getByRole('link', { name: `${title} 예제 내려받기 (JSON)`, exact: true });
    const source = await fs.readFile(path.join('examples', 'datasets', filename), 'utf8');
    const { data } = JSON.parse(source);
    const opening = page.waitForEvent('popup');
    await article.getByRole('link', { name: 'AI 학습실을 새 탭에서 열고' }).click();
    const classroom = await opening;
    const fileMenu = classroom.locator('file-menu');
    await fileMenu.getByRole('link', { name: '파일', exact: true }).click();
    await fileMenu.getByText('예제 데이터', { exact: true }).hover();
    await fileMenu.getByText(title, { exact: true }).click();
    await expect(classroom.locator('dataset-manager')).toHaveCount(Object.keys(data).length);
    for (const label of Object.keys(data)) await expect(classroom.getByText(label, { exact: true }).first()).toBeVisible();
    await classroom.close();
    if (section === 'text') {
      const intro = page.getByRole('link', { name: '한국어 감정 예제를 내려받아' });
      await expect(intro).toHaveAttribute('href', await link.getAttribute('href'));
      await expect(intro).toHaveAttribute('download', '');
    }
    const downloading = page.waitForEvent('download');
    await link.click();
    const download = await downloading;
    expect(download.suggestedFilename()).toBe(filename);
    const saved = info.outputPath(filename);
    await download.saveAs(saved);
    expect(await fs.readFile(saved, 'utf8')).toBe(source);

    await page.getByRole('link', { name: '학습실로 돌아가기', exact: true }).click();
    const menu = page.locator('file-menu');
    await menu.getByRole('link', { name: '파일', exact: true }).click();
    const choosing = page.waitForEvent('filechooser');
    await menu.getByText('학습 데이터 불러오기', { exact: true }).click();
    await (await choosing).setFiles(saved);
    await expect(page.locator('dataset-manager')).toHaveCount(Object.keys(data).length);
    for (const [label, entries] of Object.entries(data)) {
      const group = page.locator('dataset-manager').filter({ has: page.getByText(label, { exact: true }) });
      if (section === 'image') {
        await expect(group.locator('img.image-item')).toHaveCount(entries.length);
      } else {
        for (const sentence of entries) await expect(group.getByText(sentence, { exact: true })).toBeVisible();
      }
    }
  });
}

test.describe('작은 터치 화면', () => {
  test.use({ viewport: { width: 390, height: 844 }, hasTouch: true });
  test('학습실 메뉴를 터치해 한국어 감정 예제를 연다', async ({ page }) => {
    await page.goto('./');
    await page.getByRole('button', { name: '메뉴', exact: true }).tap();
    const menu = page.locator('file-menu');
    await menu.getByRole('link', { name: '파일', exact: true }).tap();
    await menu.getByText('예제 데이터', { exact: true }).tap();
    await menu.getByText('한국어 감정', { exact: true }).tap();
    await expect(page.locator('dataset-manager')).toHaveCount(2);
  });
});
