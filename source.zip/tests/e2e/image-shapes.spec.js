import fs from 'node:fs/promises';
import path from 'node:path';
import { expect, test } from '@playwright/test';
import { waitForTrainingToFinish } from './helpers/training.js';

const fixtureDir = path.resolve('tests/fixtures/shapes');
const datasetPath = path.resolve('examples/datasets/색과-도형.json');
const groups = { '빨간 원': 'circle', '파란 네모': 'square', '초록 세모': 'triangle' };

function groupCard(page, label) {
  return page.locator('dataset-manager').filter({ has: page.getByText(label, { exact: true }) });
}

async function selectFiles(page, control, paths) {
  const chooser = page.waitForEvent('filechooser');
  await control.click();
  await (await chooser).setFiles(paths);
}

async function selectSample(page) {
  const menu = page.locator('file-menu');
  await menu.getByRole('link', { name: '파일', exact: true }).click();
  await menu.getByText('예제 데이터', { exact: true }).hover();
  await menu.getByText('색과 도형', { exact: true }).click();
  for (const label of Object.keys(groups)) await expect(groupCard(page, label)).toBeVisible();
}

async function train(page) {
  await page.getByRole('button', { name: 'AI 모델 학습하기' }).click();
  await waitForTrainingToFinish(page);
}

async function classify(page, expectedLabel) {
  const evaluator = page.locator('model-eval');
  const image = path.join(fixtureDir, 'test', groups[expectedLabel] + '.png');
  await selectFiles(page, evaluator.getByRole('button', { name: '이미지 파일 선택' }), image);
  const scores = evaluator.getByRole('progressbar');
  await expect(scores).toHaveCount(Object.keys(groups).length);
  const score = async label => Number(await evaluator.getByRole('progressbar', { name: label, exact: true }).getAttribute('value'));
  const expectedScore = await score(expectedLabel);
  for (const label of Object.keys(groups)) {
    if (label !== expectedLabel) expect(expectedScore).toBeGreaterThan(await score(label));
  }
}

test.beforeEach(async ({ page }) => { await page.goto('./'); });

test('그룹별로 도형 이미지를 올려 학습하고 새 원을 분류한다', async ({ page }) => {
  await page.getByRole('button', { name: '이미지 분류' }).click();
  const names = await fs.readdir(path.join(fixtureDir, 'train'));
  for (const [label, prefix] of Object.entries(groups)) {
    await page.getByPlaceholder('새 그룹 이름').fill(label);
    await page.getByRole('button', { name: '그룹 추가' }).click();
    const card = groupCard(page, label);
    const files = names.filter(name => name.startsWith(prefix + '-') && name.endsWith('.png'));
    expect(files.length).toBeGreaterThanOrEqual(6);
    await selectFiles(page, card.getByRole('button', { name: '파일 선택', exact: true }), files.map(name => path.join(fixtureDir, 'train', name)));
    await expect(card.locator('img.image-item')).toHaveCount(files.length);
  }
  await train(page);
  await classify(page, '빨간 원');
});

test('내장 도형 예제를 학습하고 새 네모를 분류한다', async ({ page }) => {
  await selectSample(page);
  await train(page);
  await classify(page, '파란 네모');
});

test('내장 도형 예제의 학습 자료와 모델을 파일로 내려받는다', async ({ page }) => {
  await selectSample(page);
  await train(page);
  const name = page.locator('input-menu input.input');
  await name.fill('shapes');
  await name.dispatchEvent('change');
  const menu = page.locator('file-menu');
  for (const [label, extension] of [['학습 데이터 저장', '.json'], ['학습한 모델 저장', '.mdl']]) {
    await menu.getByRole('link', { name: '파일', exact: true }).click();
    const downloading = page.waitForEvent('download');
    await menu.getByText(label, { exact: true }).click();
    const download = await downloading;
    expect(await download.failure()).toBeNull();
    expect(download.suggestedFilename()).toContain('shapes');
    expect(download.suggestedFilename().endsWith(extension)).toBe(true);
    const contents = await fs.readFile(await download.path());
    expect(contents.length).toBeGreaterThan(0);
    if (extension === '.json') {
      expect(JSON.parse(contents).data).toEqual(JSON.parse(await fs.readFile(datasetPath, 'utf8')).data);
    }
  }
});

test('같은 도형 학습 자료를 다시 열어 그룹과 예시를 복원한다', async ({ page }) => {
  const dataset = JSON.parse(await fs.readFile(datasetPath, 'utf8'));
  const menu = page.locator('file-menu');
  for (let round = 0; round < 2; round++) {
    await menu.getByRole('link', { name: '파일', exact: true }).click();
    await selectFiles(page, menu.getByText('학습 데이터 불러오기', { exact: true }), datasetPath);
    await expect(page.locator('dataset-manager')).toHaveCount(Object.keys(dataset.data).length);
    for (const [label, images] of Object.entries(dataset.data)) {
      await expect(groupCard(page, label).locator('img.image-item')).toHaveCount(images.length);
    }
    if (round === 0) {
      page.once('dialog', dialog => dialog.accept());
      await groupCard(page, '빨간 원').getByRole('button', { name: '그룹 삭제' }).click();
      await expect(groupCard(page, '빨간 원')).toHaveCount(0);
    }
  }
});
