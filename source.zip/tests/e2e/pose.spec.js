import { expect, test } from '@playwright/test';
import fs from 'node:fs/promises';
import { waitForTrainingToFinish } from './helpers/training.js';

// Draw two original test figures in the browser so no photographs are distributed.
async function figure(page, raised, shift) {
  const png = await page.evaluate(({raised,shift}) => {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 320;
    const c = canvas.getContext('2d');
    c.fillStyle = '#ece7d9';
    c.fillRect(0,0,320,320);
    c.translate(shift,0);
    const limb = (positions, color, width) => {
      c.beginPath();
      c.strokeStyle=color;
      c.lineCap=c.lineJoin='round';
      c.lineWidth=width;
      positions.forEach(([x,y],i) => i ? c.lineTo(x,y) : c.moveTo(x,y));
      c.stroke();
    };
    limb([[147,164],[142,223],[135,281]], '#344e68', 22);
    limb([[173,164],[179,220],[190,283]], '#344e68', 22);
    limb([[135,283],[123,284]], '#262a36', 12);
    limb([[190,283],[202,284]], '#262a36', 12);
    limb([[139,94],[116,74],[110+shift,39]], '#c98e6f', 14);
    limb(raised ? [[181,94],[202,70],[210-shift,39]] : [[181,94],[196,131],[205-shift,162]], '#c98e6f', 14);
    c.fillStyle='#427473';
    c.beginPath(); c.moveTo(136,85); c.lineTo(183,85); c.lineTo(178,169); c.lineTo(142,169); c.fill();
    limb([[159,83],[159,68]], '#c98e6f', 13);
    c.fillStyle='#c98e6f'; c.beginPath(); c.ellipse(159,60,15,20,0,0,Math.PI*2); c.fill();
    c.fillStyle='#473a30'; c.beginPath(); c.arc(159,54,16,Math.PI,Math.PI*2); c.fill();
    return canvas.toDataURL('image/png').split(',')[1];
  }, {raised, shift});
  return {name:'pose.png',mimeType:'image/png',buffer:Buffer.from(png,'base64')};
}

test('자세 사진에서 관절을 추출해 학습·예측하고 저장한 그룹을 복원한다', async ({page}) => {
  await page.goto('./');
  await page.getByRole('button',{name:'자세 분류',exact:true}).click();
  const groups = ['한 손','두 손'];
  for (const [i,label] of groups.entries()) {
    await page.getByPlaceholder('새 그룹 이름').fill(label);
    await page.getByRole('button',{name:'그룹 추가'}).click();
    const group = page.locator('dataset-manager').filter({has:page.getByText(label,{exact:true})});
    for (const [n,shift] of [-6,0,7,11].entries()) {
      await group.locator('pose-input input').setInputFiles(await figure(page,i===1,shift));
      await expect(group.getByRole('button',{name:/자세 예시 삭제/})).toHaveCount(n+1);
    }
  }
  await page.getByRole('button',{name:'AI 모델 학습하기'}).click();
  await waitForTrainingToFinish(page);
  const evalCard = page.locator('model-eval');
  await evalCard.locator('pose-input input').setInputFiles(await figure(page,true,4));
  const score = label => evalCard.getByRole('progressbar',{name:label,exact:true}).getAttribute('value');
  await expect(evalCard.getByRole('progressbar')).toHaveCount(2);
  expect(Number(await score('두 손'))).toBeGreaterThan(Number(await score('한 손')));
  const menu = page.locator('file-menu');
  await menu.getByText('파일',{exact:true}).click();
  const downloading = page.waitForEvent('download');
  await menu.getByText('학습 데이터 저장',{exact:true}).click();
  const path = await (await downloading).path();
  const project = JSON.parse(await fs.readFile(path,'utf8'));
  expect(project.type).toBe('pose');
  for(const vector of Object.values(project.data).flat()) expect(vector.split(',').map(Number)).toHaveLength(24);
  await page.reload();
  await menu.locator('input[type=file]').setInputFiles(path);
  await expect(page.getByRole('button',{name:/자세 예시 삭제/})).toHaveCount(8);
});

test('카메라 권한 오류 뒤 다시 열어 자세를 모으고 닫으면 영상 트랙이 종료된다', async ({page}) => {
  await page.goto('./');
  await page.getByRole('button',{name:'자세 분류',exact:true}).click();
  await page.getByPlaceholder('새 그룹 이름').fill('두 손');
  await page.getByRole('button',{name:'그룹 추가'}).click();
  const camera = page.locator('dataset-manager pose-input');
  const image = await figure(page,true,3);
  await page.evaluate(encoded => {
    let first = true;
    navigator.mediaDevices.getUserMedia = async () => {
      if (first) {
        first = false;
        throw new DOMException('denied','NotAllowedError');
      }
      const photo = new Image();
      photo.src = 'data:image/png;base64,' + encoded;
      await photo.decode();
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 320;
      const stream = canvas.captureStream(10);
      window.poseTestTrack = stream.getVideoTracks()[0];
      const draw = () => {
        if (window.poseTestTrack.readyState === 'ended') return;
        canvas.getContext('2d').drawImage(photo,0,0);
        setTimeout(draw,80);
      };
      draw();
      return stream;
    };
  }, image.buffer.toString('base64'));
  const open = camera.getByRole('button',{name:/카메라/});
  await open.click();
  await expect(camera.getByRole('status')).toContainText('카메라 권한');
  await open.click();
  await camera.getByRole('button',{name:'이 자세 추가'}).click();
  await expect(page.getByRole('button',{name:/자세 예시 삭제/})).toHaveCount(1);
  await camera.getByRole('button',{name:/닫기/}).click();
  expect(await page.evaluate(() => window.poseTestTrack.readyState)).toBe('ended');
});
