import fs from 'node:fs/promises';
import { expect, test } from '@playwright/test';
import { waitForTrainingToFinish } from './helpers/training.js';

test('한국어 문장 입력, 학습, 새 문장 분류와 파일 복원', async ({page}, info) => {
  await page.setViewportSize({width: 1366, height: 768});
  const external = [], errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    if (['http:', 'https:'].includes(url.protocol) && url.hostname !== '127.0.0.1') {
      external.push(url.hostname);
      return route.abort();
    }
    return route.continue();
  });
  await page.goto('./');
  await expect(page.locator('html')).toHaveAttribute('lang', 'ko');
  const footer = page.locator('footer-copyright');
  await expect(footer.getByText('한국어판 제작 · 정윤혁', {exact:true})).toBeVisible();
  await expect(footer.getByRole('link', {name:'winf5531@gmail.com'})).toHaveAttribute('href','mailto:winf5531@gmail.com');
  await page.getByRole('button', { name: /텍스트 분류/ }).click();
  const addClass = async label => {
    await page.getByPlaceholder('새 그룹 이름').fill(label);
    await page.getByRole('button', {name: '그룹 추가'}).click();
    return page.locator('dataset-manager').filter({has: page.getByText(label, {exact:true})});
  };
  const temp = await addClass('연습');
  page.once('dialog', d => d.accept());
  await temp.getByRole('button', {name: '그룹 삭제'}).click();
  await expect(temp).toHaveCount(0);

  const examples = {
    '긍정': ['친구와 즐거운 시간을 보냈다.', '즐거운 수업을 들었다.', '함께 놀아서 즐거웠다.', '즐거운 하루라서 기분이 좋다.', '정말 즐거운 운동회였다.'],
    '부정': ['기대했는데 시험 결과가 실망스럽다.', '실망스러운 소식을 들었다.', '결과가 실망스러워서 슬펐다.', '실망스러운 하루였다.', '계속 실망스러운 일만 생겼다.']
  };
  for (const [label, entries] of Object.entries(examples)) {
    const group = await addClass(label);
    await group.getByRole('button', {name:'추가',exact:true}).click();
    await group.getByPlaceholder('한 줄에 한 문장씩 입력하세요.').fill(entries.join('\n'));
    await group.getByRole('button',{name:'문장 추가',exact:true}).click();
    await expect(group.getByText(entries[0],{exact:true})).toBeVisible();
  }
  await page.getByRole('button',{name:'AI 모델 학습하기'}).click();
  await waitForTrainingToFinish(page);
  const evaluator = page.locator('model-eval');
  await evaluator.locator('textarea').fill('동생과 즐거운 시간을 보냈다.');
  await evaluator.getByRole('button',{name:'분류하기'}).click();
  const score = label => evaluator.getByRole('progressbar', {name:label}).getAttribute('value').then(Number);
  await expect(evaluator.getByText('그룹별 예측 점수 (100점 기준)')).toBeVisible();
  expect(await score('긍정')).toBeGreaterThan(await score('부정'));
  expect(await page.evaluate(() => localStorage.getItem('lmlModel'))).toBeNull();
  await page.screenshot({path:info.outputPath('prediction.png'),fullPage:true});
  const noMatch = page.waitForEvent('dialog').then(async dialog => {
    const message = dialog.message();
    await dialog.accept();
    return message;
  });
  await evaluator.locator('textarea').fill('쀍쀍쀍');
  await evaluator.getByRole('button',{name:'분류하기'}).click();
  expect(await noMatch).toContain('겹치는 부분이 없습니다');
  const menu = page.locator('file-menu');
  await menu.getByRole('link',{name:'파일',exact:true}).click();
  const downloading = page.waitForEvent('download');
  await menu.getByText('학습 데이터 저장',{exact:true}).click();
  const download = await downloading;
  expect(download.suggestedFilename()).toMatch(/\.json$/);
  const saved = await fs.readFile(await download.path());
  expect(JSON.parse(saved.toString()).data).toEqual(examples);
  await page.reload();
  await expect(page.getByRole('button',{name:/텍스트 분류/})).toBeVisible();
  const upload = menu.locator('input[type=file]');
  await upload.setInputFiles({name:'감정.json',mimeType:'application/json',buffer:saved});
  await expect(page.locator('dataset-manager')).toHaveCount(2);
  const invalid = page.waitForEvent('dialog');
  await upload.setInputFiles({name:'오류.json',mimeType:'application/json',buffer:Buffer.from('{"type":"text","data":{"A":5}}')});
  const alert = await invalid;
  expect(alert.message()).toContain('학습 자료 파일');
  await alert.accept();
  await expect(page.getByText(examples['긍정'][0],{exact:true})).toBeVisible();
  expect(external).toEqual([]);
  expect(errors).toEqual([]);
});
