import { expect } from '@playwright/test';

export const waitForTrainingToFinish = async (page, { timeout = 150_000 } = {}) => {
  const modelLearn = page.locator('model-learn').first();
  await expect(modelLearn).toBeVisible();
  await expect.poll(() => modelLearn.evaluate(el => ({
    trained: el.modelHasBeenTrained, loading: el.showModalLearn
  })), { timeout }).toEqual({ trained: true, loading: false });
};
