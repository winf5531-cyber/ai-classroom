import { expect, test } from '@playwright/test';

const homeTitle = 'AI 학습실 | 로그인 없이 쓰는 머신러닝 실습 사이트';
const homeHeading = '나만의 데이터로 머신러닝 실습하기';

test('홈 소개는 실습을 고르기 전에만 보이고 문서 제목이 유지된다', async ({ page }) => {
  await page.goto('./');
  await expect(page.getByRole('button', { name: '텍스트 분류', exact: true })).toBeVisible();
  await expect(page).toHaveTitle(homeTitle);
  await expect(page.getByRole('heading', { level: 1, name: homeHeading })).toBeVisible();
  await expect(page.getByRole('link', { name: '다섯 가지 분류 실습 안내' })).toBeVisible();
  await page.getByRole('button', { name: '텍스트 분류', exact: true }).click();
  await expect(page.getByRole('heading', { name: homeHeading })).toBeHidden();
  await page.goto('./?locale=en');
  await expect(page.getByRole('heading', { name: 'What kind of data would you like to use?' })).toBeVisible();
  await expect(page.getByRole('heading', { name: homeHeading })).toBeHidden();
});

test.describe('자바스크립트 없이 수업 페이지 찾기', () => {
  test.use({ javaScriptEnabled: false });
  test('홈에서 감정 분석 수업과 다섯 실습 안내를 읽을 수 있다', async ({ page }) => {
    await page.goto('./');
    await expect(page.getByRole('heading', { name: homeHeading })).toBeVisible();
    await page.getByRole('link', { name: '긍정과 부정 문장으로 감정 분석하기' }).click();
    await expect(page).toHaveTitle(/텍스트 분류 실습/);
    await expect(page.getByRole('heading', { name: '새 문장으로 예측 확인하기' })).toBeVisible();
    await page.getByRole('link', { name: '다른 분류 실습 보기' }).click();
    await expect(page.locator('#lessons article h3')).toHaveCount(5);
  });
});
