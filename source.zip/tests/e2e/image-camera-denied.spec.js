import path from 'node:path';
import { expect, test } from '@playwright/test';

test('카메라 사용을 거절한 뒤에도 그룹에 이미지 파일을 추가할 수 있다', async ({ context, page, baseURL }) => {
  await context.grantPermissions([], { origin: new URL(baseURL).origin });
  await page.goto('./');
  await page.getByRole('button', { name: '이미지 분류' }).click();
  await page.locator('model-train #inputLabelName').fill('빨간 원');
  await page.getByRole('button', { name: '그룹 추가' }).click();

  const card = page.locator('dataset-manager').filter({ hasText: '빨간 원' });
  await expect(card.getByText(/이미지 파일을 올려도 됩니다/)).toBeVisible();
  const message = page.waitForEvent('dialog').then(async dialog => {
    const text = dialog.message();
    await dialog.accept();
    return text;
  });
  await card.getByRole('button', { name: '카메라' }).click();
  expect(await message).toMatch(/카메라.*권한/);
  await expect(card.locator('video')).toBeHidden();
  const choose = page.waitForEvent('filechooser');
  await card.getByRole('button', { name: /올리기|업로드|파일 선택/ }).click();
  await (await choose).setFiles(path.join(process.cwd(), 'tests/fixtures/shapes/test/circle.png'));
  await expect(card.locator('img.image-item')).toHaveCount(1);
  expect(await card.locator('img.image-item').evaluate(image => image.decode().then(() => image.naturalWidth))).toBeGreaterThan(0);
});
