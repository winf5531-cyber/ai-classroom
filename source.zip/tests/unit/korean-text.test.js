import { describe, expect, test } from 'bun:test';
import { buildKoreanVocabulary, koreanBagOfWords, koreanTextFeatures } from '../../src/services/korean-text.js';

describe('Korean bag of words', () => {
  test('composed and decomposed Hangul yield identical counts; Latin terms retain the original handling', () => {
    const sentence = 'AI 42 환경을 보호한다.';
    expect(koreanTextFeatures(sentence)).toEqual(koreanTextFeatures(sentence.normalize('NFD')));
    expect(koreanTextFeatures(sentence)).toContain('ai');
    expect(koreanTextFeatures('Café school!')).toEqual(['caf', 'school']);
  });

  test('partial word forms and alternative spacing share syllable sequences', () => {
    const original = koreanTextFeatures('환경을 보호한다.');
    for (const sample of ['환경보호를 실천한다.', '환경을 보호하지 않는다.', '환경을 보호하는 것이 좋다.']) {
      const features = koreanTextFeatures(sample);
      for (const term of ['ko:g:환경', 'ko:g:보호']) {
        expect(original).toContain(term);
        expect(features).toContain(term);
      }
      expect(features).not.toEqual(original);
    }
    const grams = text => koreanTextFeatures(text).filter(term => term.startsWith('ko:g:'));
    expect(grams('환경 보호')).toEqual(grams('환경보호'));
    expect(grams('환경. 보호')).not.toContain('ko:g:경보');
    expect(grams('환경\n보호')).not.toContain('ko:g:경보');
  });

  test('negation survives tokenization; completely unseen terms receive zero counts', () => {
    const words = buildKoreanVocabulary(['보호하지 않는다.', '보호한다.']);
    const index = new Map(words.map((term, i) => [term, i]));
    expect(koreanBagOfWords('보호하지않는다', index)[index.get('ko:g:지않')]).toBe(1);
    expect(koreanBagOfWords('보호한다', index)[index.get('ko:g:지않')]).toBe(0);
    expect(koreanBagOfWords('로봇', index).some(Boolean)).toBe(false);
  });
});
