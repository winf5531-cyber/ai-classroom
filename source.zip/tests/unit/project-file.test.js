import { expect, test } from 'bun:test';
import { readProject } from '../../src/utils/project-file.js';
test('Korean projects retain arbitrary labels and empty classes', () => {
  const project = readProject('{"type":"text","data":{"__proto__":["안녕하세요"],"기분 좋은 날":[]}}');
  expect([...project.dataset]).toEqual([['__proto__', new Set(['안녕하세요'])], ['기분 좋은 날', new Set()]]);
});
test('malformed projects fail before they can replace student work', () => {
  for (const s of ['{}', '{"type":"numerical","data":{"A":["1,2","3"]}}', '{"type":"image","data":{"A":["https://example.com/a.jpg"]}}']) {
    expect(() => readProject(s)).toThrow();
  }
});
