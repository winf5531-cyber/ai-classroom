import { expect, test } from 'bun:test';
import { bodyPoints, parsePose, poseVector } from '../../src/services/pose.js';
import { readProject } from '../../src/utils/project-file.js';

test('pose input ignores face landmarks and low-confidence joints', () => {
  const raw = Array.from({length:17}, (_,i) => [i/20, i/30, i === 7 ? 0.2 : 0.9]).flat();
  const points = bodyPoints(raw);
  expect(points).toHaveLength(12);
  expect(points[0]).toEqual([5/30,5/20]);
  expect(points[2]).toBeNull();
  const scaled = points.map(p => p && p.map(n => 0.15 + n/2));
  expect(poseVector(points)).toBe(poseVector(scaled));
  const entry = poseVector(points);
  const project = readProject(JSON.stringify({type:'pose',data:{sample:[entry]}}));
  expect([...project.dataset.get('sample')]).toEqual([entry]);
  expect(parsePose(entry)[2]).toBeNull();
  expect(project.dimension).toBe(24);
});

test('an empty frame cannot be captured and invalid projects are rejected', () => {
  expect(poseVector(Array(12).fill(null))).toBeNull();
  for (const value of ['1,2', Array(24).fill('NaN').join(','), Array(24).fill('-1').join(',')]) {
    expect(() => readProject(JSON.stringify({type:'pose',data:{sample:[value]}}))).toThrow();
  }
});
