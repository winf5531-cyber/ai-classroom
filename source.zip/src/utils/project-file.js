import { parsePose } from '../services/pose.js';

// Decode the whole project before replacing the current classroom activity.
export function readProject(source) {
  const { type, data } = JSON.parse(source);
  if (!['text', 'numerical', 'image', 'audio', 'pose'].includes(type) ||
      !data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Unsupported project');
  }
  const dataset = new Map();
  let dimension = type === 'pose' ? 24 : 0;
  for (const [label, entries] of Object.entries(data)) {
    if (!label.trim() || !Array.isArray(entries)) throw new Error('Invalid class');
    const items = new Set();
    dataset.set(label, items);
    for (let entry of entries) {
      if (entry === '') continue;
      if (type === 'audio') {
        const { rawAudio, spectrogram } = entry;
        entry = {
          rawAudio: { ...rawAudio, data: Float32Array.from(Object.values(rawAudio.data)) },
          spectrogram: { ...spectrogram, data: Float32Array.from(Object.values(spectrogram.data)) }
        };
      } else {
        if (typeof entry !== 'string') throw new Error('Invalid example');
        if (type === 'pose') parsePose(entry);
        if (type === 'image' && !/^data:image\/(?:jpeg|png|webp|gif|svg\+xml);base64,/i.test(entry)) throw new Error('Invalid image');
        if (type === 'numerical') {
          const values = entry.split(',');
          if (values.some(v => !v.trim() || !Number.isFinite(Number(v)))) throw new Error('Invalid vector');
          dimension ||= values.length;
          if (values.length !== dimension) throw new Error('Inconsistent dimensions');
          entry = values.map(v => Number(v).toFixed(4)).join(',');
        }
      }
      items.add(entry);
    }
  }
  return { type, dataset, dimension };
}
