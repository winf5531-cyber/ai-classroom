import { LitElement, html } from 'lit';
import { updateWhenLocaleChanges } from '@lit/localize';

export class InitMessage extends LitElement {

    static properties = {
        title: { type: String },
        message: { type: String },
        timeout: { type: Number}
    };

    constructor() {
        super();
        updateWhenLocaleChanges(this);
    }

    updated(){
        this.title = process.env.INIT_MESSAGE_TITLE;
        this.message = process.env.INIT_MESSAGE_DESCRIPTION;
        this.timeout = process.env.INIT_MESSAGE_TIMEOUT;

        setTimeout(() => {this.parentElement.style.display='none'}, this.timeout);
    }

    render() {

        return html`
<article class="message is-warning">
  <div class="message-header">
    <p>${this.title}</p>
    <button @click=${() => {this.parentElement.style.display='none'}} class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body">
    ${this.message}
  </div>
</article>
    `
    }

    createRenderRoot() {
    const root = super.createRenderRoot();
    const initShadow = globalThis.__lmlInitShadowRoot;
    if (typeof initShadow === 'function') {
      initShadow(this, root);
    }
    return root;
  }
}

window.customElements.define('init-message', InitMessage);
