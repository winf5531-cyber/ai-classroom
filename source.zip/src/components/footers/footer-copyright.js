import { LitElement, html } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { upstreamUrl } from '../../brand.js';
import { assetUrl } from '../../utils/assetPaths.js';

export class FooterCopyRight extends LitElement {
  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  render() {
    return html`
      <style>
        :host { display: block; }
        footer { max-width: 78rem; margin: 1.5rem auto 0; border-top: 1px solid #d8e1dd;
          padding: 1.4rem 0 2rem; color: #50645b; font-size: .875rem; line-height: 1.65; }
        p { margin: 0 0 .25rem; }
        .save-note { margin: 0 0 1rem; color: #304c42; }
        .links { margin: .6rem 0; display: flex; flex-wrap: wrap; gap: .3rem 1.25rem; }
        a { color: #175b4d; text-underline-offset: .2em; }
      </style>
      <footer>
        <p class="save-note">${msg('Training data is processed in this browser. Save your data using the file menu before refreshing or closing this tab.', { id: 'class-device' })}</p>
        <p>${msg('This is an unofficial Korean educational service based on the LearningML open-source project.', { id: 'class-unofficial' })}</p>
        <p>${msg('Korean edition', { id: 'korean-edition' })} · <span lang="ko">정윤혁</span></p>
        <p>${msg('Contact', { id: 'edition-contact' })} · <a href="mailto:winf5531@gmail.com">winf5531@gmail.com</a></p>
        <div class="links">
          <a href=${upstreamUrl} target="_blank" rel="noopener noreferrer">${msg('Original project', { id: 'class-upstream' })}</a>
          <a href=${assetUrl('licenses.html')}>${msg('Source code and licenses', { id: 'class-licenses' })}</a>
        </div>
        <p lang="en">LearningML® © 2024 Juan David Rodríguez García</p>
        <p>${msg('Pose estimation model', { id: 'pose-model-credit' })} · <a href=${assetUrl('licenses.html#pose-model')}>Google MoveNet SinglePose Lightning (Apache 2.0)</a></p>
      </footer>
    `;
  }
}
customElements.define('footer-copyright', FooterCopyRight);
