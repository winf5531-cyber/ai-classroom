import { LitElement, html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { assetUrl } from '../../utils/assetPaths.js';
import { siteName } from '../../brand.js';
import './language-menu';
import './file-menu';
import './input-menu';
import './learn-menu';
import './mode-toggle-menu';
import './about-menu';

export class MainMenu extends LitElement {
  static properties = {
    advancedMode: { type: Object, attribute: 'advanced-mode' },
    menu: { type: String },
    modelName: { type: String },
    navBarMenuActive: { type: Boolean }
  };

  constructor() {
    super();
    this.modelName = '';
    this.navBarMenuActive = false;
    this.addEventListener('change-input-name', event => { this.modelName = event.detail; });
    updateWhenLocaleChanges(this);
  }

  render() {
    const editor = this.menu !== 'home';
    return html`
      <style>
        nav.navbar { border-bottom: 1px solid #cedbd4; background: #fff; color: #213e35;
          min-height: 4.3rem; border-radius: .7rem; padding: 0 .5rem; }
        .brand { display: inline-flex; gap: .65rem; align-items: center; font: inherit; font-size: 1.28rem;
          font-weight: 750; letter-spacing: -.04em; white-space: nowrap; color: #1b493c; }
        .brand img { width: 2.35rem; height: 2.35rem; max-height: none; }
        .navbar-burger { align-self: center; border: 0; background: transparent; }
        button.navbar-item { border: 0; background: transparent; font: inherit; cursor: pointer; }
        @media (min-width: 1024px) {
          .navbar-menu, .navbar-start { min-width: 0; }
          nav .navbar-menu { flex: 1 1 0; }
          .navbar-start { flex-wrap: wrap; }
          .navbar-end { flex-shrink: 0; }
          .navbar-brand { padding-inline-end: .8rem; }
        }
        @media (max-width: 1023px) {
          .navbar-brand { min-height: 4rem; }
          .navbar-menu.is-active { box-shadow: none; padding-bottom: 1rem; }
        }
      </style>
      <nav class="navbar" aria-label=${msg('Menu', { id: 'class-menu' })}>
        <div class="navbar-brand">
          <a class="navbar-item brand" href=${window.location.href}>
            <img src=${assetUrl('images/classroom-mark.svg')} alt="">
            <span>${siteName}</span>
          </a>
          <button type="button" @click=${() => { this.navBarMenuActive = !this.navBarMenuActive; }}
            class=${classMap({ 'navbar-burger': true, 'is-active': this.navBarMenuActive })}
            aria-label=${msg('Menu', { id: 'class-menu' })} aria-controls="navigation"
            aria-expanded=${String(this.navBarMenuActive)}>
            <span aria-hidden="true"></span><span aria-hidden="true"></span>
            <span aria-hidden="true"></span><span aria-hidden="true"></span>
          </button>
        </div>
        <div id="navigation" class=${classMap({ 'navbar-menu': true, 'is-active': this.navBarMenuActive })}>
          <div class="navbar-start">
            <language-menu class="component"></language-menu>
            <file-menu ?showSaveDataset=${editor} ?showSaveModel=${editor} class="component"></file-menu>
            ${editor ? html`<input-menu name=${this.modelName} class="component"></input-menu>` : ''}
            <learn-menu class="component"></learn-menu>
            ${editor ? html`<mode-toggle-menu .advanced=${Boolean(this.advancedMode?.enabled)} class="component"></mode-toggle-menu>` : ''}
            ${editor && this.advancedMode?.enabled ? html`
              <button type="button" class="navbar-item" @click=${this.openPlaygroundPage}>${msg('Playground')}</button>
            ` : ''}
            ${editor && process.env.URL_SCRATCH ? html`
              <a class="navbar-item" href=${this.scratchUrl()} target="scratch" rel="noopener">Scratch</a>
            ` : ''}
          </div>
          <div class="navbar-end"><about-menu class="component"></about-menu></div>
        </div>
      </nav>
    `;
  }

  scratchUrl() {
    const url = new URL(process.env.URL_SCRATCH, window.location.href);
    url.searchParams.set('locale', document.documentElement.lang);
    return url.href;
  }

  openPlaygroundPage() {
    this.dispatchEvent(new CustomEvent('open-playground-page', { bubbles: true, composed: true }));
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    globalThis.__lmlInitShadowRoot?.(this, root);
    return root;
  }
}

customElements.define('main-menu', MainMenu);
