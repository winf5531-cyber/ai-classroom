import {configureLocalization} from '@lit/localize';
import {allLocales, sourceLocale, targetLocales} from './locale-codes.js';

export const {getLocale, setLocale} = configureLocalization({
  sourceLocale,
  targetLocales,
  loadLocale: (locale) => import(`../../i18n/${locale}.js`),
});

export const setLocaleFromUrl = async () => {
  const url = new URL(window.location.href);
  const requested = url.searchParams.get('locale');
  const locale = allLocales.includes(requested) ? requested : 'ko';
  await setLocale(locale);
  if (document.documentElement) document.documentElement.lang = getLocale();
};