import { LitElement, html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { ContextConsumer } from '@lit/context';
import { datasetContext, dataTypeContext, modelContext } from '../../contexts.js';
import { readProject } from '../../utils/project-file.js';
import { getLocale } from './localization.js';
import { saveAs } from 'file-saver-es';

const exampleDatasetModules = import.meta.glob('/examples/datasets/*.json', {
  query: '?raw',
  import: 'default',
  eager: false
});
const formatDatasetLabel = (fileName) =>
  fileName
    .replace(/\.json$/i, '')
    .replace(/[_-]+/g, ' ')
    .trim();
const exampleDatasets = Object.entries(exampleDatasetModules)
  .map(([path, contents]) => {
    const fileName = path.split('/').pop() || path;
    return {
      name: fileName.replace(/\.json$/i, ''),
      label: formatDatasetLabel(fileName),
      contents
    };
  })
  .sort((a, b) => a.label.localeCompare(b.label, 'es'));


export class FileMenu extends LitElement {
  static properties = {
    showSaveDataset: { type: Boolean },
    showSaveModel: { type: Boolean},
    dropdownOpen: { type: Boolean }
  }

  _datasetConsumer = new ContextConsumer(this, { context: datasetContext, subscribe: true  });
  _dataTypeConsumer = new ContextConsumer(this, { context: dataTypeContext, subscribe: true });
  _modelConsumer = new ContextConsumer(this, { context: modelContext, subscribe: true });

  constructor() {
    super();
    updateWhenLocaleChanges(this);
    this.dropdownOpen = false;
    this.handleExternalToggle = this.handleExternalToggle.bind(this);
    this.handleDocumentPointerDown = this.handleDocumentPointerDown.bind(this);
    this.handleDocumentKeydown = this.handleDocumentKeydown.bind(this);
  }

  connectedCallback() {
    super.connectedCallback();
    window.addEventListener('lml-menu-toggle', this.handleExternalToggle);
    document.addEventListener('pointerdown', this.handleDocumentPointerDown, true);
    document.addEventListener('keydown', this.handleDocumentKeydown);
  }

  disconnectedCallback() {
    window.removeEventListener('lml-menu-toggle', this.handleExternalToggle);
    document.removeEventListener('pointerdown', this.handleDocumentPointerDown, true);
    document.removeEventListener('keydown', this.handleDocumentKeydown);
    super.disconnectedCallback();
  }

  handleExternalToggle(event) {
    if (event?.detail?.menu !== 'file' && event?.detail?.open) {
      this.dropdownOpen = false;
    }
  }

  handleDocumentPointerDown(event) {
    if (!this.dropdownOpen) return;
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    const clickedInside = path.includes(this);
    if (!clickedInside) {
      this.closeDropdown();
    }
  }

  handleDocumentKeydown(event) {
    if (event.key === 'Escape' && this.dropdownOpen) {
      this.closeDropdown();
    }
  }

  setDropdownOpen(nextOpen) {
    if (this.dropdownOpen === nextOpen) return;
    this.dropdownOpen = nextOpen;
    window.dispatchEvent(new CustomEvent('lml-menu-toggle', {
      detail: { menu: 'file', open: this.dropdownOpen }
    }));
  }

  closeDropdown() {
    this.setDropdownOpen(false);
  }

  saveDataset(e) {


    let jsonDataset = Object.create(null);
    this._datasetConsumer.value.forEach((value, key) => {
      jsonDataset[key] = Array.from(value);
    });

    jsonDataset = {
      type: this._dataTypeConsumer.value.type,
      data: jsonDataset
    }

    let jsonString = JSON.stringify(jsonDataset);


    const blob = new Blob([jsonString], { type: 'application/json' });
    saveAs(blob, (this._dataTypeConsumer.value.name || msg('Dataset')).replace(/\.json$/i, '') + '.json');
  }

  async saveModel(e){    
    const model = this._modelConsumer.value;
    if(!model?.model && !model?.isTrained){
      alert(msg("You have to build a model first"));
      return;
    }
    let datatype = { ...this._dataTypeConsumer.value, name: this._dataTypeConsumer.value.name || msg('Dataset') };
    if (datatype.type === 'text') datatype.vocabulary = model.trainingVocabulary;
    try {
      await model.saveToDisk(datatype);
    } catch {
      alert(msg('Could not save the model. Try saving the training data.', { id: 'model-save-error' }));
    }
  }

  loadDataset(contents, name) {
    let project;
    try {
      project = readProject(contents);
    } catch {
      alert(msg('Choose a valid project JSON file.', { id: 'project-invalid' }));
      return;
    }
    this.dispatchEvent(new CustomEvent('load-project', {
      bubbles: true, composed: true, detail: { ...project, name }
    }));
    this.dispatchEvent(new CustomEvent('change-input-name', { bubbles: true, composed: true, detail: name }));
  }

  async onLoaded(event) {
    const input = event.target;
    const file = input.files[0];
    if (!file) return;
    input.value = '';
    try {
      this.loadDataset(await file.text(), file.name.replace(/\.json$/i, ''));
    } catch {
      alert(msg('Choose a valid project JSON file.', { id: 'project-invalid' }));
    }
  }

  openFileBrowser(){
    this.closeDropdown();
    this.querySelector('#fileInput')?.click();
  }

  async loadExampleDataset(example) {
    if (!example) return;
    this.closeDropdown();
    try {
      this.loadDataset(await example.contents(), example.name);
    } catch {
      alert(msg('Choose a valid project JSON file.', { id: 'project-invalid' }));
    }
  }

  toggleDropdown(event) {
    event.preventDefault();
    event.stopPropagation();
    this.setDropdownOpen(!this.dropdownOpen);
  }

  render() {

    return html`
    <style>
      .navbar-dropdown .navbar-item.has-dropdown.is-submenu {
        position: relative;
      }

      .navbar-dropdown .navbar-item.has-dropdown.is-submenu > .navbar-link {
        padding-right: 2.25em;
      }

      .navbar-dropdown .navbar-item.has-dropdown.is-submenu > .navbar-link::after {
        border: 2px solid currentColor;
        border-top: 0;
        border-left: 0;
        content: "";
        display: block;
        height: 0.45em;
        width: 0.45em;
        transform: rotate(-45deg);
        position: absolute;
        right: 0.75em;
        top: 50%;
        margin-top: -0.2em;
      }

      .navbar-dropdown .navbar-item.has-dropdown.is-submenu > .navbar-link {
        color: hsla(171, 100%, 29%, 1);
      }

      .navbar-dropdown .navbar-item.has-dropdown.is-submenu > .navbar-dropdown {
        display: none;
        position: absolute;
        left: 100%;
        top: -0.5rem;
        min-width: 240px;
      }

      .navbar-dropdown .navbar-item.has-dropdown.is-submenu.is-hoverable:hover > .navbar-dropdown,
      .is-submenu:focus-within > .navbar-dropdown {
        display: block;
      }

      @media screen and (max-width: 1023px) {
        .navbar-dropdown .navbar-item.has-dropdown.is-submenu > .navbar-dropdown {
          position: static;
          min-width: auto;
          box-shadow: none;
        }
      }
    </style>
    <input id="fileInput" hidden accept=".json,application/json" type="file" @change=${this.onLoaded}>

    <div class=${classMap({
      'navbar-item': true,
      'has-dropdown': true,
      'is-active': this.dropdownOpen
    })}>
        <a class="navbar-link" href="#" @click=${this.toggleDropdown}>
          ${msg("File")}
        </a>
    
        <div class="navbar-dropdown">
          
          <a href="" class="navbar-item" @click=${this.closeDropdown}>${msg("New")}</a>
          <a @click=${this.openFileBrowser} class="navbar-item">${msg("Upload dataset from your computer")}</a>
          ${this.showSaveDataset
        ? html`<a @click=${(e) => { this.closeDropdown(); this.saveDataset(e); }} class="navbar-item">${msg("Save dataset to your computer")}</a>`
        : html``
          }
          ${this.showSaveModel
        ? html`<a @click=${(e) => { this.closeDropdown(); this.saveModel(e); }} class="navbar-item">${msg("Save model to your computer")}</a>`
        : html``
          }

          <div class="navbar-item has-dropdown is-hoverable is-submenu">
            <a class="navbar-link" tabindex="0">${msg("Sample datasets", { id: "sample-datasets" })}</a>
            <div class="navbar-dropdown">
              ${exampleDatasets.filter(example => getLocale() !== 'ko' || ['한국어-감정', '색과-도형'].includes(example.name)).map(
                (example) =>
                  html`<a class="navbar-item" @click=${() => this.loadExampleDataset(example)}>
                    ${example.label}
                  </a>`
              )}
            </div>
          </div>
        </div>
    </div>
        `
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    const initShadow = globalThis.__lmlInitShadowRoot;
    if (typeof initShadow === 'function') {
      initShadow(this, root);
    }
    return root;
  }
}

window.customElements.define('file-menu', FileMenu);
