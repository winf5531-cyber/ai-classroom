import { LitElement, html } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { siteName } from '../../brand.js';
import { assetUrl } from '../../utils/assetPaths.js';

export class AboutMenu extends LitElement {
  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  render() {
    return html`
      <style>
        :host { display: flex; align-items: center; padding: .5rem; }
        button { font: inherit; font-weight: 600; color: #244c40; border-radius: .5rem;
          background: #eff6ef; padding: .45rem .85rem; border: 1px solid #c9dacc; cursor: pointer; }
        dialog { background: white; color: #233b35; border: 1px solid #c9dacc; border-radius: 1rem;
          padding: 1.7rem; max-width: min(28rem, 80vw); box-shadow: 0 8px 48px #173d322a; }
        dialog::backdrop { background: #10282370; }
        h2 { margin: 0 0 1rem; } p { line-height: 1.65; }
      </style>
      <button type="button" @click=${() => this.renderRoot.querySelector('dialog').showModal()}>${msg('About')}</button>
      <dialog aria-labelledby="about-title">
        <h2 id="about-title">${siteName}</h2>
        <p>${msg('This is an unofficial Korean educational service based on the LearningML open-source project.', { id: 'class-unofficial' })}</p>
        <p>${msg('Training data is processed in this browser. Save your data using the file menu before refreshing or closing this tab.', { id: 'class-device' })}</p>
        <p>${msg('LearningML® is a registered trademark of Juan David Rodríguez García.', { id: 'class-trademark' })}</p>
        <p><a href=${assetUrl('licenses.html')} target="_blank" rel="noopener">${msg('Source code and licenses', { id: 'class-licenses' })}</a></p>
        <form method="dialog"><button>${msg('Close')}</button></form>
      </dialog>
    `;
  }
}
customElements.define('about-menu', AboutMenu);
