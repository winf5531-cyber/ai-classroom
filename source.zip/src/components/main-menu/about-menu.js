import { LitElement, html } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { siteName, upstreamUrl, editionAuthor, contactEmail, poseModelCredit } from '../../brand.js';
import { assetUrl } from '../../utils/assetPaths.js';

export class AboutMenu extends LitElement {
  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  render() {
    return html`
      <style>
        :host { display: flex; align-items: center; padding: .5rem; }
        button { font: inherit; font-weight: 600; color: #244c40; border-radius: .5rem;
          background: #eff6ef; padding: .45rem .85rem; border: 1px solid #c9dacc; cursor: pointer; }
        dialog { background: white; color: #233b35; border: 1px solid #c9dacc; border-radius: 1rem;
          box-sizing: border-box; width: min(34rem, calc(100% - 2rem)); max-height: calc(100% - 2rem);
          padding: clamp(1rem, 4vw, 1.7rem); overflow: auto; box-shadow: 0 8px 48px #173d322a; }
        dialog::backdrop { background: #10282370; }
        h2 { margin: 0 0 1rem; }
        p, dl { margin: .75rem 0; line-height: 1.65; }
        dl { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: .4rem 1rem;
          border-top: 1px solid #d8e1dd; padding-top: 1rem; }
        dt { font-weight: 600; } dd { margin: 0; overflow-wrap: anywhere; }
        a { color: #175b4d; text-underline-offset: .2em; }
        .links { display: flex; flex-wrap: wrap; gap: .4rem 1rem; } form { text-align: end; }
      </style>
      <button type="button" @click=${() => this.renderRoot.querySelector('dialog').showModal()}>${msg('About')}</button>
      <dialog aria-labelledby="about-title">
        <h2 id="about-title">${siteName}</h2>
        <p>${msg('This is an unofficial Korean educational service based on the LearningML open-source project.', { id: 'class-unofficial' })}</p>
        <p>${msg('Train an AI model with text, images, numbers, sounds or poses, then test it on new examples. No sign-in is needed.', { id: 'about-activities' })}</p>
        <p>${msg('In the pose activity, MoveNet estimates joint positions. Your classifier learns to recognize each group from the examples you collect.', { id: 'about-pose' })}</p>
        <p>${msg('Training data is processed in this browser. Save your data using the file menu before refreshing or closing this tab.', { id: 'class-device' })}</p>
        <dl>
          <dt>${msg('Korean edition', { id: 'korean-edition' })}</dt><dd lang="ko">${editionAuthor}</dd>
          <dt>${msg('Contact', { id: 'edition-contact' })}</dt><dd><a href=${'mailto:' + contactEmail}>${contactEmail}</a></dd>
          <dt>${msg('Pose estimation model', { id: 'pose-model-credit' })}</dt>
          <dd><a href=${assetUrl('licenses.html#pose-model')} target="_blank" rel="noopener">${poseModelCredit}</a></dd>
        </dl>
        <p>${msg('LearningML® is a registered trademark of Juan David Rodríguez García.', { id: 'class-trademark' })}</p>
        <p class="links"><a href=${upstreamUrl} target="_blank" rel="noopener noreferrer">${msg('Original project', { id: 'class-upstream' })}</a>
          <a href=${assetUrl('licenses.html')} target="_blank" rel="noopener">${msg('Source code and licenses', { id: 'class-licenses' })}</a></p>
        <form method="dialog"><button>${msg('Close')}</button></form>
      </dialog>
    `;
  }
}
customElements.define('about-menu', AboutMenu);
