import { LitElement, html } from 'lit';
import { ContextConsumer } from '@lit/context';
import { dataTypeContext } from '../../contexts.js';
import { assetUrl } from '../../utils/assetPaths.js';

export class ModelCard extends LitElement {
  _dataTypeConsumer = new ContextConsumer(this, { context: dataTypeContext, subscribe: true });

  static properties = {
    title: { type: String },
    description: { type: String },
    type: { type: String }
  };

  loadEditor() {
    this._dataTypeConsumer.value.type = this.type;
    if (this.type === 'pose') this._dataTypeConsumer.value.dimension = 24;
    this.dispatchEvent(new CustomEvent('load-model-editor', {
      bubbles: true,
      composed: true,
      detail: this.type
    }));
  }

  render() {
    return html`
      <style>
        :host { display: block; --paper: #dceee0; --dot: #b5d4bc; }
        :host([type=image]) { --paper: #e1edf4; --dot: #bfd3df; }
        :host([type=numerical]) { --paper: #f5ebd9; --dot: #dfd0b7; }
        :host([type=audio]) { --paper: #ede6f2; --dot: #d5c6df; }
        :host([type=pose]) { --paper: #f5e7df; --dot: #dfc7bb; }
        button { width: 100%; height: 100%; padding: 0; overflow: hidden; border: 1px solid #cdd9d4;
          border-radius: .95rem; color: #183e36; background: white; font: inherit; text-align: start;
          box-shadow: 0 3px 9px #143e3210; cursor: pointer; display: flex; flex-direction: column; }
        button:hover { border-color: #517f6e; box-shadow: 0 5px 14px #173d321b; }
        button:focus-visible { outline: 3px solid #28735c; outline-offset: 3px; }
        figure { width: 100%; aspect-ratio: 1.9; display: grid; place-items: center; margin: 0;
          background-color: var(--paper); background-image: radial-gradient(var(--dot) 1px, transparent 1px); background-size: 12px 12px; }
        img { display: block; width: 90%; height: 100%; max-height: 12rem; }
        .copy { padding: 1.2rem 1.1rem 1.4rem; }
        strong { display: block; font-size: 1.3rem; line-height: 1.4; letter-spacing: -.035em; }
        .description { display: block; margin-top: .45rem; color: #536560; line-height: 1.55; }
        @media (max-width: 30rem) { figure { aspect-ratio: 2.8; } }
      </style>
      <button type="button" aria-labelledby="card-title" aria-describedby="description" @click=${this.loadEditor}>
        <figure class="image is-clickable" aria-hidden="true">
          <img src=${assetUrl(`images/classroom-${this.type}.svg`)} alt="">
        </figure>
        <span class="copy">
          <strong id="card-title">${this.title}</strong>
          <span id="description" class="description">${this.description}</span>
        </span>
      </button>
    `;
  }
}

customElements.define('model-card', ModelCard);
