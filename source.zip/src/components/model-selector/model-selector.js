import { LitElement, html } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import './model-card.js';

export class ModelSelector extends LitElement {
  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  render() {
    return html`
      <style>
        :host { display: block; max-width: 78rem; margin: 0 auto; }
        section { padding: clamp(1.8rem, 5vw, 4rem) 0 clamp(1.5rem, 5vw, 3.6rem); }
        h1 { margin: 0; color: #1d3533; font-size: clamp(1.8rem, 3.6vw, 2.9rem); font-weight: 750; line-height: 1.24; letter-spacing: -.055em; }
        p { margin: .75rem 0 1.8rem; color: #506460; line-height: 1.65; }
        .models { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1.1rem; }
        @media (max-width: 58rem) { .models { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
        @media (max-width: 30rem) { .models { grid-template-columns: minmax(0, 1fr); } }
      </style>
      <section aria-labelledby="choice">
        <h1 id="choice">${msg('What kind of data would you like to use?', { id: 'class-select-kind' })}</h1>
        <p>${msg('Choose a data type and train an AI model with your own examples.', { id: 'class-select-hint' })}</p>
        <div class="models">
          <model-card type="text" title=${msg('Text recognition')} description=${msg('Teach the computer to recognize text')}></model-card>
          <model-card type="image" title=${msg('Image recognition')} description=${msg('Teach the computer to recognize images')}></model-card>
          <model-card type="numerical" title=${msg('Number recognition')} description=${msg('Teach the computer to recognize number sets')}></model-card>
          <model-card type="audio" title=${msg('Sound recognition')} description=${msg('Teach the computer to recognize sounds')}></model-card>
        </div>
      </section>
    `;
  }
}
customElements.define('model-selector', ModelSelector);
