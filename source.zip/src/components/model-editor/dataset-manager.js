import { LitElement, html } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { ContextConsumer } from '@lit/context';
import { dataTypeContext, datasetContext } from '../../contexts.js';
import { classMap } from 'lit/directives/class-map.js';
import { collectExample, playRawAudio } from '../../services/lml-algorithms-bridge.js';



export class DatasetManager extends LitElement {

  _dataTypeConsumer = new ContextConsumer(this, { context: dataTypeContext, subscribe: true });
  _datasetConsumer = new ContextConsumer(this, { context: datasetContext, subscribe: true });

  static properties = {
    editinglabelName: { type: Boolean },
    labelName: { type: String },
    textEntry: { type: String },
    editText: { type: Boolean },
    addTextsWindowOpened: { type: Boolean },
    cameraOpened: { type: Boolean },
    dataset: { type: Set }
  };

  constructor() {
    super();
    this.editinglabelName = false;
    this.labelName = "Unnamed";
    this.textEntry = "";
    this.editText = false;
    this.addTextsWindowOpened = false;
    this.cameraOpened = false;
    this.deletedSounds = 0;
    this.stopCollecting = false;
    updateWhenLocaleChanges(this);
  }

  connectedCallback() {
    super.connectedCallback();

  }

  editlabelName() {
    if (this.editinglabelName) {
      let oldLabel = this.labelName;
      const nextName = this.querySelector("#inputlabelName").value.trim();
      if (!nextName || (oldLabel !== nextName && this._datasetConsumer.value.has(nextName))) {
        alert(msg('Enter a new class name.', { id: 'class-name-error' }));
        return;
      }
      this.labelName = nextName;
      if (this._datasetConsumer.value.has(oldLabel) && oldLabel != this.labelName) {
        this._datasetConsumer.value.set(this.labelName,
          this._datasetConsumer.value.get(oldLabel));
        this._datasetConsumer.value.delete(oldLabel);
        this.dispatchEvent(new CustomEvent('remove-label', { bubbles: true, composed: true }));
      }

    }
    this.editinglabelName = !this.editinglabelName;
  }

  _removeClass() {
    if (this._datasetConsumer.value.has(this.labelName)) {
      this._datasetConsumer.value.delete(this.labelName);
    }


    this.dispatchEvent(new CustomEvent('remove-label', {
      bubbles: true, composed: true
    }));
  }

  removeClass() {
    if (confirm(msg("Are you sure?"))) {
      this._removeClass();
    }
  }

  ////
  // Funciones para manejar los datasets de textos
  ///
  closeAddTextWindow() {
    this.addTextsWindowOpened = false;
    this.querySelector("#inputTexts").value = "";
  }

  openAddTextWindow() {
    this.editText = false;
    this.addTextsWindowOpened = true;
  }

  isValidNumberEntry(entry) {
    let items = this.fromCSV2Array(entry);

    // primero miramos que todas los items separados por coma sean números
    if (items.some(item => isNaN(item))) return false;

    // después comprobamos si this.dimension es 0, lo cual significa que es
    // la primera entrada y será la que define la dimensión de los vectores
    if (this._dataTypeConsumer.value.dimension == 0) {
      this._dataTypeConsumer.value.dimension = items.length;
    }

    // por último comprobamos que la dimensión del array items coincida con this.dimension
    if (this._dataTypeConsumer.value.dimension != items.length) return false;

    // si hemos llegado hasta aquí, todo está bien

    return true;

  }

  addTextToDataset(texts) {

    for (let entry of texts.split("\n")) {
      entry = entry.trim();
      if (!entry) continue;
      if (this._dataTypeConsumer.value.type == 'numerical' && !this.isValidNumberEntry(entry)) {
        alert(msg("Invalid entry"));
        break;
      }

      this._datasetConsumer.value.set(this.labelName,
        this._datasetConsumer.value.get(this.labelName).add(entry));
    }

    this.requestUpdate();
  }

  addTexts() {
    this.editText = false;
    let texts = this.querySelector("#inputTexts").value;
    if (this._datasetConsumer.value.has(this.labelName)) {
      this.addTextToDataset(texts);
    }

    this.closeAddTextWindow();
  }

  editTexts(e) {
    let texts = this.querySelector("#inputTexts").value;
    // Si el texto ha sido cambiado por el usuario, es decir `texts` no coincide 
    // con el atributo this.textEntry, hay que borrar el valor que tenía ...
    if (this.textEntry != texts) {
      this._datasetConsumer.value.get(this.labelName).delete(this.textEntry);
      this.textEntry = texts;
    }

    // Y añadir el nuevo valor (cambiado por el usuario), es decir, conseguimos
    // la edición borrando la entrada y añadiendo la nueva entrada modificada.
    this.addTexts();
  }

  removeTextEntry(e, entry) {
    this.editText = true;
    let textToDelete;
    if (typeof entry === 'string') {
      textToDelete = entry;
    } else {
      const sourceEl = e?.target?.closest('[text-entry]');
      textToDelete = sourceEl ? sourceEl.getAttribute('text-entry') : null;
    }
    if (confirm(msg("Surely you want to delete this item?"))) {
      if (this._datasetConsumer.value.has(this.labelName) && textToDelete !== null) {
        this._datasetConsumer.value.get(this.labelName).delete(textToDelete);
      }

      this.requestUpdate();
    }
  }

  editTextEntry(e) {
    let entry = e.currentTarget.getAttribute("text-entry");
    this.textEntry = entry;
    this.editText = true;


    this.addTextsWindowOpened = true;
    this.querySelector("#inputTexts").value = entry;
  }

  _uploadTexts() {
    this.querySelector(`#textFileInput_${CSS.escape(this.labelName)}`)?.click();
  }

  onLoadedText(event) {
    // Obtener la lista de archivos seleccionados
    const file = event.target.files[0];

    if (!file) {
      console.error("No se seleccionó ninguna imagen.");
      return;
    }

    const reader = new FileReader();

    let that = this;
    reader.onload = function (e) {
      const textContent = e.target.result;
      that.addTextToDataset(textContent);
    };

    reader.readAsText(file);
  }


  ////
  // Funciones para manejar los datasets de imágenes
  //
  addImageToDataset(imageB64) {
    if (this._datasetConsumer.value.has(this.labelName)) {
      this._datasetConsumer.value.set(this.labelName,
        this._datasetConsumer.value.get(this.labelName).add(imageB64));
    }
    this.requestUpdate();
  }

  _uploadImages() {
    this.querySelector(`#imageFileInput_${CSS.escape(this.labelName)}`)?.click();
  }

  onLoaded(event) {
    // Obtener la lista de archivos seleccionados
    const files = event.target.files;

    // Convertir cada archivo a Base64
    Array.from(files).forEach(file => {
      const reader = new FileReader();

      reader.onload = () => {
        this.addImageToDataset(reader.result);
      };

      // Leer el archivo como Data URL (Base64)
      reader.readAsDataURL(file);
    });
  }


  async openCamera() {
    this.video = this.querySelector("#video");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (!this.isConnected) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      this.stream = stream;
      this.video.srcObject = stream;
      this.cameraOpened = true;
    } catch {
      window.alert(msg("Can't init camera. Are you using it in another application?"));
    }
  }

  closeCamera() {
    this.cameraOpened = false;
    this.stream?.getTracks().forEach(track => {
      track.stop();
    })
    this.stream = null;
  }

  disconnectedCallback() {
    this.stopCollecting = true;
    this.closeCamera();
    super.disconnectedCallback();
  }

  takePictureFromCamera() {
    if (this.stream) {
      const canvas = document.createElement('canvas');
      canvas.width = this.video.width;
      canvas.height = this.video.height;
      const context = canvas.getContext('2d');

      // Dibujar el fotograma actual en el lienzo
      context.drawImage(this.video, 0, 0, canvas.width, canvas.height);

      // Obtener el contenido del lienzo como datos base64
      const base64String = canvas.toDataURL('image/png');
      this.addImageToDataset(base64String);
      this.requestUpdate();
    }
  }

  ////
  // Funciones para manejar los datasets de audio
  //
  async collectExampleInterval() {

    if (this.stopCollecting) {

      return;  // Salir de la función si stopCollecting es true
    }
    try {
      const result = await collectExample(this.labelName);

      // Agregar los datos resultantes al dataset
      if (this._datasetConsumer.value.get(this.labelName)) {
        this._datasetConsumer.value.get(this.labelName).add({
          'rawAudio': result.rawAudio,
          'spectrogram': result.spectrogram
        });
      }
      // Actualizar el componente
      this.requestUpdate();

      // Una vez que la promesa se resuelva, vuelve a llamar a la función
      this.collectExampleInterval();
    } catch (error) {
      this.stopRecording();
      alert(msg('Check microphone access and the network connection.', { id: 'microphone-error' }));
    }
  }

  collectAudioSample() {
    const recordButton = this.querySelector(`#recordButton_${CSS.escape(this.labelName)}`);
    const stopButton = this.querySelector(`#stopButton_${CSS.escape(this.labelName)}`);
    if (!recordButton || !stopButton) return;
    recordButton.disabled = true;
    stopButton.disabled = false;

    this.stopCollecting = false;
    this.collectExampleInterval();
  }

  stopRecording() {
    this.stopCollecting = true;
    const recordButton = this.querySelector(`#recordButton_${CSS.escape(this.labelName)}`);
    const stopButton = this.querySelector(`#stopButton_${CSS.escape(this.labelName)}`);
    if (!recordButton || !stopButton) return;
    recordButton.disabled = false;
    stopButton.disabled = true;
  }

  templateButtons(editorType) {
    switch (editorType) {
      case 'text':
        return this.templateTextButtons();
      case 'image':
        return this.templateImageButtons();
      case 'numerical':
        return this.templateNumberButtons();
      case 'audio':
        return this.templateAudioButtons();
    }
  }

  templateData(editorType) {
    switch (editorType) {
      case 'text':
        return this.templateTextData();
      case 'image':
        return this.templateImageData();
      case 'numerical':
        return this.templateNumberData();
      case 'audio':
        return this.templateAudioData();
    }
  }

  templateTextButtons() {
    return html`
    <input 
      id="textFileInput_${this.labelName}"
      accept="text/*"
      hidden="true" 
      type="file"
      @change=${this.onLoadedText} 
      >
    <div class="panel-block is-justify-content-center">    
      <div class="field is-grouped">
        <p class="control">      
          <button @click=${this.openAddTextWindow} class="button  is-primary is-fullwidth">
            <span class="icon">
            <i class="far fa-keyboard"></i>
            </span>
            <span>${msg('Add')}</span>
          </button>
        </p>
        <p class="control">
          <button @click=${this._uploadTexts} class="button  is-primary is-fullwidth">
            <span class="icon">
            <i class="fas fa-upload"></i>
            </span>
            <span>${msg('Load')}</span>
          </button>
        </p>
      </div>
    </div>
    `;
  }

  templateImageButtons() {
    return html`
    <p class="mb-2">${msg("Allow camera access to take a photo on this device, or upload an image.", { id: "camera-purpose" })}</p>
    <input 
      id="imageFileInput_${this.labelName}"
      accept="image/png, image/jpeg, image/webp, image/svg+xml"
      hidden="true" 
      type="file"
      @change=${this.onLoaded} 
      multiple>

    <div class="panel-block is-justify-content-center">
      <div class="field is-grouped">
      ${!this.cameraOpened
        ? html`
          <p class="control">      
            <button @click=${this._uploadImages} class="button mr-1 is-primary is-fullwidth">
              <span class="icon">
              <i class="fas fa-images"></i>
              </span>
              <span>${msg('Upload')}</span>
            </button>
          </p>
          <p class="control"> 
            <button @click=${this.openCamera} class="button mr-1 is-primary is-fullwidth">
              <span class="icon">
              <i class="fas fa-camera"></i>
              </span>
              <span>${msg('Camera')}</span>
            </button>
          </p>`

        : html`
          <p class="control"> 
            <button @click=${this.takePictureFromCamera} class="button mr-1 is-primary is-fullwidth">
              <span class="icon">
                <i class="fas fa-camera"></i>
              </span>
              <span>${msg('Shot')}</span>
            </button>
          </p>
          <p class="control"> 
            <button @click=${this.closeCamera} class="button mr-1 is-primary is-fullwidth">
              <span class="icon">
                <i class="fas fa-xmark"></i>
              </span>
              <span>${msg('Close')}</span>
            </button>
          </p>`

      }
      </div>
    </div>
    `;
  }

  templateNumberButtons() {
    return html`
    <input 
      id="textFileInput_${this.labelName}"
      accept="text/*"
      hidden="true" 
      type="file"
      @change=${this.onLoadedText} 
      >
    <div class="panel-block is-justify-content-center">
      <div class="field is-grouped">
        <p class="control">
          <button @click="${this.openAddTextWindow}" class="button is-primary is-fullwidth">
            <span class="icon">
            <i class="far fa-keyboard"></i>
            </span>
            <span>${msg('Add')}</span>
          </button>
        </p>
        <p class="control">
          <button @click="${this._uploadTexts}" class="button  is-primary is-fullwidth">
            <span class="icon">
            <i class="fas fa-upload"></i>
            </span>
            <span>${msg('Load')}</span>
          </button>
        </p>
      </div>
    </div>

    </div>
    `;
  }

  templateAudioButtons() {
    return html`    
    </div>
    <div class="panel-block is-justify-content-center">
      <div class="field is-grouped">
        <p class="control">
          <button id="recordButton_${this.labelName}" @click="${this.collectAudioSample}" class="button is-primary is-fullwidth">
            <span class="icon">
              <i class="fas fa-microphone"></i>
            </span>
            <span>${msg('Record')}</span>
          </button>
        </p>
        <p class="control">
          <button id="stopButton_${this.labelName}" @click="${this.stopRecording}" disabled class="button  is-primary is-fullwidth">
            <span class="icon">
              <i class="fas fa-circle-stop"></i>
            </span>
            <span>${msg('Stop')}</span>
          </button>
        </p>
      </div>
    </div>

    </div>
    `;
  }

  get modalTitle() {
    const type = this._dataTypeConsumer.value.type;
    switch(type) {
      case 'text': return msg("Add one or more text examples");
      case 'numerical': return msg("Add one or more numeric examples");
      default: return msg("Add one or more examples");
    }
  }

  get modalPlaceholder() {
    const type = this._dataTypeConsumer.value.type;
    switch(type) {
      case 'text': return msg("Separate each text by a line break");
      case 'numerical': return msg("Separate each number by a line break");
      default: return msg("Enter the examples below, separated by line breaks");
    }
  }

  get addButtonText() {
    const type = this._dataTypeConsumer.value.type;
    switch(type) {
      case 'text': return msg("Add text examples");
      case 'numerical': return msg("Add numeric examples");
      default: return msg("Examples to add");
    }
  }

  get editTextButtonLabel() {
    const type = this._dataTypeConsumer.value.type;
    switch(type) {
      case 'text': return msg("Edit text examples");
      case 'numerical': return msg("Edit numeric examples");
      default: return msg("Edit examples");
    }
  }

  templateTextData() {
    return html`
      
      <div class="container itemdata p-3">
        ${this._datasetConsumer.value.get(this.labelName)
        ? Array.from(this._datasetConsumer.value.get(this.labelName)).reverse().map((entry, index) =>
          html`
          <div class="panel-block">
            <span @click=${this.editTextEntry} text-entry=${entry} class="mr-2">
              <i class="fas fa-pen-to-square"></i>
            </span>
            <span @click=${(e) => this.removeTextEntry(e, entry)} text-entry=${entry} class="panel-icon is-clickable">
              <i class="fas fa-trash-can"></i>
            </span>
            <p> <span class="truncate">${entry}</p>
          </div>
          `
        )
        : html``
      }        
      </div>

      <div class=${classMap({ "modal": true, "is-active": this.addTextsWindowOpened })}>
        <div class="modal-background"></div>
        <div class="modal-content">
          <nav class="panel has-background-warning">
            <p class="panel-heading has-background-warning">
              ${this.modalTitle}
            </p>
            
            <div class="panel-block">
              <textarea id="inputTexts" class="textarea" placeholder="${this.modalPlaceholder}" rows="10"></textarea>
            </div>
            
            <div class="panel-block">
                ${this.editText
        ? html`
                    <button @click=${this.editTexts} class="button is-primary  is-fullwidth">
                      ${this.editTextButtonLabel}
                    </button>`
        : html`
                    <button @click=${this.addTexts} class="button is-primary  is-fullwidth">
                      ${this.addButtonText}
                    </button>`
      }
            </div>
          </nav>          
        </div>
        <button @click=${this.closeAddTextWindow} class="modal-close is-large" aria-label=${msg("Close")}></button>
      </div>
    `;
  }

  deleteImage(label, image) {
    let removeImage = confirm(msg("Surely you want to delete this item?"));
    if (removeImage) {
      this._datasetConsumer.value.get(label).delete(image);
      this.requestUpdate();
    }
  }

  templateImageData() {
    return html`
      <div class="container itemdata p-3">    
      <video id="video" ?hidden=${!this.cameraOpened} width="400px" height="300px" autoplay></video>
      
      ${this._datasetConsumer.value.get(this.labelName) && !this.cameraOpened
        ? Array.from(this._datasetConsumer.value.get(this.labelName)).reverse().map((image, index) =>
          html`
            <img @click=${() => { this.deleteImage(this.labelName, image) }} class="image-item" src=${image}/>
          `
        )
        : html``
      }     
    </div>
    `;
  }

  fromCSV2Array(csv) {
    return csv.split(",").map(v => parseFloat(v));
  }

  templateNumberData() {
    return html`        
      <div class="container itemdata p-3">
        <div class="table-container">
          <table class="table is-bordered">
            <tbody>
            ${this._datasetConsumer.value.get(this.labelName)
        ? Array.from(this._datasetConsumer.value.get(this.labelName)).reverse().map((entry, index) =>
          html`
                <tr>
                  <td>
                    <div class="panel-block">
                      <span @click=${this.editTextEntry} text-entry=${entry} class="mr-2 is-clickable">
                        <i class="fas fa-pen-to-square"></i>
                      </span>
                      <span @click=${(e) => this.removeTextEntry(e, entry)} text-entry=${entry} class="is-clickable">
                        <i class="fas fa-trash-can"></i>
                      </span> 
                    </div>
                  </td>
                  ${this.fromCSV2Array(entry).map(e =>
            html`<td>${e}</td>`)}
                </tr>
                `
        )
        : html``
      } 
            </tbody>
          </table>
        </div>
      </div>

      <div class=${classMap({ "modal": true, "is-active": this.addTextsWindowOpened })}>
        <div class="modal-background"></div>
        <div class="modal-content">
          <nav class="panel has-background-warning">
            <p class="panel-heading has-background-warning">
              ${this.modalTitle}
            </p>
            
            <div class="panel-block">
              <textarea id="inputTexts" class="textarea" placeholder="${this.modalPlaceholder}" rows="10"></textarea>
            </div>
            
            <div class="panel-block">
                ${this.editText
        ? html`
                    <button @click=${this.editTexts} class="button is-primary  is-fullwidth">
                      ${this.editTextButtonLabel}
                    </button>`
        : html`
                    <button @click=${this.addTexts} class="button is-primary  is-fullwidth">
                      ${this.addButtonText}
                    </button>`
      }
            </div>
          </nav>          
        </div>
        <button @click=${this.closeAddTextWindow} class="modal-close is-large" aria-label=${msg("Close")}></button>
      </div>
    `;
  }

  templateAudioData() {

    return html`
      <div class="container itemdata p-3">    
        <div class="buttons" id="sounds_${this.labelName}">
         
        ${this._datasetConsumer.value.get(this.labelName)
        ? Array.from(this._datasetConsumer.value.get(this.labelName)).map((soundData, index) => {

          function play() {

            playRawAudio(soundData.rawAudio);
          }

          function remove() {
            this._datasetConsumer.value.get(this.labelName).delete(soundData);
            this.requestUpdate();
          }

          return html`
            <div class="audio-container">
              <span aria-hidden="true">♫</span>
              <div class="sample-text">${index + 1}</div>
              <button @click=${play} class="button is-primary play-button">
                <i class="fas fa-play" aria-hidden="true"></i>
              </button>
              <button @click=${remove} class="button is-danger delete-button">
                <i class="fas fa-trash" aria-hidden="true"></i>
              </button>
            </div>
              `
        }

        )
        : html``
      }
         
        </div>
      </div>
    `;
  }

  render() {

    return html`
<nav class="panel mb-3">
  <p class="panel-heading">
        ${this.editinglabelName
        ? html`<input id="inputlabelName" style="width: 200px;" class="input" value=${this.labelName} type="text" placeholder=${msg("New class name")}>`
        : html`<span id="labelName">${this.labelName}</span> <span class="tag is-info">${this._datasetConsumer.value.get(this.labelName)?.size ?? 0}</span>`
      }

      <button class="button is-small" aria-label=${msg("Rename class", { id: "class-rename" })} @click=${this.editlabelName}><i class=${classMap({ "fas": true, "fa-check": this.editinglabelName, "fa-pen-to-square": !this.editinglabelName })}></i></button>
      
      <button class="button is-small" aria-label=${msg("Delete class", { id: "class-delete" })} @click=${this.removeClass}><i class="far fa-trash-can"></i></button> 
        
  </p>
  
  ${this.templateData(this._dataTypeConsumer.value.type)}

  ${this.templateButtons(this._dataTypeConsumer.value.type)}
   
</nav>
    `
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    const initShadow = globalThis.__lmlInitShadowRoot;
    if (typeof initShadow === 'function') {
      initShadow(this, root);
    }
    return root;
  }
}

window.customElements.define('dataset-manager', DatasetManager);
