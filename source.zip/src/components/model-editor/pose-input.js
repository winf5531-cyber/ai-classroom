import { LitElement, html, svg, nothing } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { detectPose } from '../../services/pose-detector.js';
import { poseEdges, poseVector } from '../../services/pose.js';

export function poseDrawing(points) {
  return svg`<svg viewBox="-0.08 -0.08 1.16 1.16" width="64" height="64" aria-hidden="true">
    ${poseEdges.map(([a,b]) => points[a] && points[b] ? svg`<line x1=${points[a][0]} y1=${points[a][1]} x2=${points[b][0]} y2=${points[b][1]} stroke="#236e5c" stroke-width=".034"/>` : nothing)}
    ${points.map(p => p ? svg`<circle cx=${p[0]} cy=${p[1]} r=".035" fill="#176450"/>` : nothing)}
  </svg>`;
}

class PoseInput extends LitElement {
  static properties = {
    testing: {type: Boolean}, camera: {state: true}, busy: {state: true},
    hint: {state: true}, ready: {state: true}, preview: {state: true}
  };
  generation = 0;
  hint = '';
  stopOther = event => { if (event.detail !== this) this.stop(); };
  onVisibility = () => { if (document.hidden) this.stop(); };

  constructor() {
    super();
    updateWhenLocaleChanges(this);
    this.frame = document.createElement('canvas');
    this.frame.width = this.frame.height = 192;
  }

  connectedCallback() {
    super.connectedCallback();
    window.addEventListener('pose-camera-change', this.stopOther);
    document.addEventListener('visibilitychange', this.onVisibility);
  }

  disconnectedCallback() {
    this.stop();
    window.removeEventListener('pose-camera-change', this.stopOther);
    document.removeEventListener('visibilitychange', this.onVisibility);
    super.disconnectedCallback();
  }

  stop() {
    this.generation++;
    clearTimeout(this.timer);
    this.stream?.getTracks().forEach(track => track.stop());
    this.stream = null;
    if (this.video) this.video.srcObject = null;
    this.video = null;
    this.vector = null;
    this.camera = this.busy = this.ready = false;
    this.hint = '';
  }

  async openCamera() {
    window.dispatchEvent(new CustomEvent('pose-camera-change', { detail: this }));
    this.stop();
    const generation = this.generation;
    this.preview = null;
    this.busy = true;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
      if (generation !== this.generation) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      this.stream = stream;
      this.camera = true;
      this.video = document.createElement('video');
      this.video.muted = this.video.playsInline = true;
      this.video.srcObject = stream;
      await this.video.play();
      if (generation !== this.generation) return;
      this.busy = false;
      this.track(generation);
    } catch {
      if (generation !== this.generation) return;
      this.stop();
      this.hint = msg('Check camera access or choose a photo.', { id: 'pose-camera-error' });
    }
  }

  drawFrame(source, width, height) {
    const ctx = this.frame.getContext('2d', {willReadFrequently: true});
    const scale = 192 / Math.max(width, height);
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, 192, 192);
    ctx.drawImage(source, (192-width*scale)/2, (192-height*scale)/2, width*scale, height*scale);
  }

  async track(generation) {
    try {
      this.drawFrame(this.video, this.video.videoWidth, this.video.videoHeight);
      const points = await detectPose(this.frame);
      if (generation !== this.generation) return;
      const ctx = this.renderRoot.querySelector('canvas').getContext('2d');
      ctx.drawImage(this.frame, 0, 0);
      ctx.strokeStyle = '#77ffcf';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (const [a,b] of poseEdges) {
        if (!points[a] || !points[b]) continue;
        ctx.moveTo(points[a][0]*192, points[a][1]*192);
        ctx.lineTo(points[b][0]*192, points[b][1]*192);
      }
      ctx.stroke();
      ctx.fillStyle = '#fff';
      for (const point of points.filter(Boolean)) {
        ctx.beginPath();
        ctx.arc(point[0]*192, point[1]*192, 2, 0, Math.PI*2);
        ctx.fill();
      }
      this.vector = poseVector(points);
      this.ready = Boolean(this.vector);
      this.hint = this.ready ? '' : this.missingPose();
      this.timer = setTimeout(() => this.track(generation), 100);
    } catch {
      if (generation !== this.generation) return;
      this.stop();
      this.hint = this.modelError();
    }
  }

  missingPose() {
    return msg('Show one person with both shoulders and arms in view.', { id: 'pose-missing' });
  }
  modelError() {
    return msg('Could not read the pose. Please try again.', { id: 'pose-error' });
  }

  async openPhoto(event) {
    const file = event.target.files[0];
    event.target.value = '';
    if (!file) return;
    this.stop();
    const generation = this.generation;
    this.preview = null;
    this.busy = true;
    let bitmap;
    try {
      bitmap = await createImageBitmap(file);
      if (generation !== this.generation) return;
      this.drawFrame(bitmap, bitmap.width, bitmap.height);
      const points = await detectPose(this.frame);
      if (generation !== this.generation) return;
      this.vector = poseVector(points);
      if (this.vector) {
        this.preview = points;
        this.submit();
      } else this.hint = this.missingPose();
    } catch {
      if (generation === this.generation) this.hint = this.modelError();
    } finally {
      bitmap?.close();
      if (generation === this.generation) this.busy = false;
    }
  }

  submit() {
    if (this.vector) this.dispatchEvent(new CustomEvent('pose-sample', {
      detail: this.vector, bubbles: true, composed: true
    }));
  }

  render() {
    return html`<style>
      canvas { width: min(100%, 20rem); border-radius: .4rem; }
      [hidden] {display:none!important}
    </style>
    <canvas width="192" height="192" ?hidden=${!this.camera} aria-label=${msg('Camera pose preview', { id: 'pose-preview' })}></canvas>
    ${this.preview ? poseDrawing(this.preview) : nothing}
    <div class="buttons mt-2">
      ${this.camera ? html`
        <button class="button is-primary" ?disabled=${!this.ready} @click=${this.submit}>${this.testing ? msg('Check') : msg('Capture this pose', {id:'pose-add'})}</button>
        <button class="button" @click=${this.stop}>${msg('Close camera')}</button>` : html`
        <button class="button is-primary" ?disabled=${this.busy} @click=${this.openCamera}>${msg('Take from camera')}</button>
        <button class="button is-primary is-light" ?disabled=${this.busy} @click=${() => this.renderRoot.querySelector('input').click()}>${msg('Choose a photo', {id:'pose-photo'})}</button>`}
    </div>
    <input type="file" hidden accept="image/jpeg,image/png,image/webp" @change=${this.openPhoto}>
    <p role="status">${this.busy ? msg('Preparing pose input…', {id:'pose-busy'}) : this.hint}</p>`;
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    globalThis.__lmlInitShadowRoot?.(this, root);
    return root;
  }
}
customElements.define('pose-input', PoseInput);
