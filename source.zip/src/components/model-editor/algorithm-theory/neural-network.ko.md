# 신경망

사진 한 장에 고양이, 개, 새 중 어떤 동물이 있는지 분류한다고 해 봅시다. 입력층은 이미지의 특징을 받아들이고, 은닉층은 특징을 조합해요. 출력층은 그룹마다 점수를 내요.

## 학습은 어떻게 이뤄질까요?

1. 예시를 넣어 그룹별 점수를 구해요.
2. 예측과 정답의 차이를 손실이라는 값으로 계산해요.
3. 손실을 줄이는 방향을 계산해 연결의 가중치를 바꿔요.
4. 여러 예시로 이 과정을 반복해요.

## 결과 읽기

아래 그림은 세 그룹의 점수를 합계 100이 되도록 표시한 예예요. 고양이 점수가 84로 가장 높아 모델은 고양이를 선택했어요. 새로운 사진을 실제로 얼마나 자주 맞히는지는 학습에 쓰지 않은 사진으로 측정해 보세요.

<svg role="img" aria-label="신경망이 사진을 분류하는 과정" style="max-width:100%;height:auto" width="760" height="420" viewBox="0 0 760 420" xmlns="http://www.w3.org/2000/svg">
  <rect width="760" height="420" fill="#f7f9fc"/>
  <text x="24" y="34" font-family="Arial, sans-serif" font-size="24" fill="#1f2937">신경망이 사진을 분류하는 과정</text>
  <rect x="30" y="80" width="180" height="180" rx="12" fill="#e0f2fe" stroke="#0284c7"/>
  <text x="50" y="110" font-family="Arial, sans-serif" font-size="16" fill="#0c4a6e">입력층</text>
  <text x="50" y="138" font-family="Arial, sans-serif" font-size="14" fill="#075985">이미지 특징</text>
  <text x="50" y="160" font-family="Arial, sans-serif" font-size="14" fill="#075985">윤곽선, 모양 등</text>
  <line x1="210" y1="170" x2="290" y2="170" stroke="#64748b" stroke-width="3"/>
  <polygon points="290,170 280,164 280,176" fill="#64748b"/>
  <rect x="300" y="80" width="180" height="180" rx="12" fill="#fff7ed" stroke="#ea580c"/>
  <text x="320" y="110" font-family="Arial, sans-serif" font-size="16" fill="#9a3412">은닉층</text>
  <text x="320" y="138" font-family="Arial, sans-serif" font-size="14" fill="#7c2d12">특징을 조합해</text>
  <text x="320" y="160" font-family="Arial, sans-serif" font-size="14" fill="#7c2d12">점수를 계산</text>
  <line x1="480" y1="170" x2="560" y2="170" stroke="#64748b" stroke-width="3"/>
  <polygon points="560,170 550,164 550,176" fill="#64748b"/>
  <rect x="570" y="60" width="160" height="240" rx="12" fill="#ecfeff" stroke="#0891b2"/>
  <text x="588" y="90" font-family="Arial, sans-serif" font-size="16" fill="#164e63">출력층</text>
  <text x="588" y="124" font-family="Arial, sans-serif" font-size="14" fill="#0e7490">고양이 84%</text>
  <text x="588" y="152" font-family="Arial, sans-serif" font-size="14" fill="#0e7490">개 11%</text>
  <text x="588" y="180" font-family="Arial, sans-serif" font-size="14" fill="#0e7490">새 5%</text>
  <text x="588" y="220" font-family="Arial, sans-serif" font-size="16" fill="#0e7490">예측한 그룹</text>
  <text x="588" y="244" font-family="Arial, sans-serif" font-size="18" fill="#166534">고양이</text>
</svg>
