# K-최근접 이웃

아래 그림에서 파란 점과 주황 점은 이미 정답을 아는 예시예요. 초록 점은 새로 분류하려는 예시예요. 모델은 초록 점에서 가장 가까운 점을 정해진 개수(K)만큼 찾고, 그중 가장 많은 그룹에 투표해요.

가장 가까운 점 다섯 개 중 파란 점이 세 개, 주황 점이 두 개라면 파란 그룹의 득표 비율은 3/5, 주황 그룹의 득표 비율은 2/5예요. 이웃 다섯 개만 놓고 보면 파란 그룹이 이겨요. 실제로 이 예측이 맞았는지는 정답을 가진 별도 예시로 확인할 수 있어요.

## 실험해 보기

이웃 수를 1로 설정한 뒤 다른 그룹의 점 하나를 무리 안에 그려 보세요. 이웃 수를 5로 늘리면 그 점 주변의 분류 경계가 어떻게 달라지나요?

<svg role="img" aria-label="K-최근접 이웃으로 분류하기 (K=5)" style="max-width:100%;height:auto" width="720" height="420" viewBox="0 0 720 420" xmlns="http://www.w3.org/2000/svg">
  <rect width="720" height="420" fill="#f7f9fc"/>
  <text x="24" y="36" font-family="Arial, sans-serif" font-size="24" fill="#1f2937">K-최근접 이웃으로 분류하기 (K=5)</text>
  <g stroke="#dbe3ef" stroke-width="1">
    <line x1="80" y1="70" x2="80" y2="360"/><line x1="160" y1="70" x2="160" y2="360"/>
    <line x1="240" y1="70" x2="240" y2="360"/><line x1="320" y1="70" x2="320" y2="360"/>
    <line x1="400" y1="70" x2="400" y2="360"/><line x1="480" y1="70" x2="480" y2="360"/>
    <line x1="560" y1="70" x2="560" y2="360"/><line x1="640" y1="70" x2="640" y2="360"/>
    <line x1="80" y1="70" x2="640" y2="70"/><line x1="80" y1="130" x2="640" y2="130"/>
    <line x1="80" y1="190" x2="640" y2="190"/><line x1="80" y1="250" x2="640" y2="250"/>
    <line x1="80" y1="310" x2="640" y2="310"/><line x1="80" y1="360" x2="640" y2="360"/>
  </g>
  <g fill="#2563eb">
    <circle cx="180" cy="140" r="9"/><circle cx="300" cy="170" r="9"/><circle cx="260" cy="160" r="9"/>
    <circle cx="300" cy="220" r="9"/><circle cx="210" cy="270" r="9"/>
  </g>
  <g fill="#f97316">
    <circle cx="470" cy="130" r="9"/><circle cx="485" cy="180" r="9"/><circle cx="550" cy="140" r="9"/>
    <circle cx="500" cy="250" r="9"/><circle cx="560" cy="220" r="9"/>
  </g>
  <circle cx="380" cy="200" r="10" fill="#10b981" stroke="#065f46" stroke-width="2"/>
  <text x="395" y="195" font-family="Arial, sans-serif" font-size="14" fill="#065f46">새 점</text>
  <g stroke="#6b7280" stroke-width="2" stroke-dasharray="6 5">
    <line x1="380" y1="200" x2="300" y2="220"/>
    <line x1="380" y1="200" x2="260" y2="160"/>
    <line x1="380" y1="200" x2="485" y2="180"/>
    <line x1="380" y1="200" x2="470" y2="130"/>
    <line x1="380" y1="200" x2="300" y2="170"/>
  </g>
  <rect x="80" y="375" width="14" height="14" fill="#2563eb"/><text x="100" y="387" font-family="Arial, sans-serif" font-size="14" fill="#1f2937">파란 그룹</text>
  <rect x="220" y="375" width="14" height="14" fill="#f97316"/><text x="240" y="387" font-family="Arial, sans-serif" font-size="14" fill="#1f2937">주황 그룹</text>
  <rect x="380" y="375" width="14" height="14" fill="#10b981"/><text x="400" y="387" font-family="Arial, sans-serif" font-size="14" fill="#1f2937">분류할 점</text>
</svg>
