# 나이브 베이즈

어떤 메시지를 ‘광고’와 ‘일반’ 중 하나로 분류한다고 해 봅시다. 모델은 각 그룹의 예시에서 ‘무료’와 ‘당첨’이라는 특징이 얼마나 자주 나타나는지 살펴봐요. 같은 그룹 안에서 특징들이 서로 독립이라고 가정해 각 특징의 영향을 곱해요.

## 간단한 계산

광고와 일반 메시지를 10개씩 모았다고 가정해요. 광고에서 ‘무료’는 6번, ‘당첨’은 3번 나타났고, 일반 메시지에서는 각각 1번, 2번 나타났어요. 두 단어만 특징으로 사용한 예에서 ‘무료 당첨’의 점수는 다음과 같아요.

- 광고 점수는 0.5 × 0.6 × 0.3 = 0.09예요.
- 일반 점수는 0.5 × 0.1 × 0.2 = 0.01이에요.

두 값을 합계 0.10으로 나누면 상대 점수는 각각 0.90, 0.10이 돼요. 이 예에서는 광고가 높은 점수를 받아요. 특징이 자주 함께 나타나거나 학습 자료가 치우치면 결과도 달라져요. 실제 수치 입력을 다루는 이 실험실에서는 그룹별 특징의 평균과 분산을 이용해 점수를 계산해요.

<svg role="img" aria-label="나이브 베이즈의 분류 과정" style="max-width:100%;height:auto" width="760" height="420" viewBox="0 0 760 420" xmlns="http://www.w3.org/2000/svg">
  <rect width="760" height="420" fill="#f7f9fc"/>
  <text x="24" y="34" font-family="Arial, sans-serif" font-size="24" fill="#1f2937">나이브 베이즈의 분류 과정</text>
  <rect x="30" y="70" width="300" height="90" rx="12" fill="#e0f2fe" stroke="#0284c7"/>
  <text x="45" y="100" font-family="Arial, sans-serif" font-size="15" fill="#0c4a6e">입력한 메시지</text>
  <text x="45" y="125" font-family="Arial, sans-serif" font-size="18" fill="#0c4a6e">무료 당첨</text>
  <text x="45" y="146" font-family="Arial, sans-serif" font-size="13" fill="#075985">특징 단어 두 개</text>
  <line x1="340" y1="115" x2="420" y2="115" stroke="#64748b" stroke-width="3"/>
  <polygon points="420,115 410,109 410,121" fill="#64748b"/>
  <rect x="440" y="70" width="280" height="120" rx="12" fill="#fff7ed" stroke="#ea580c"/>
  <text x="455" y="98" font-family="Arial, sans-serif" font-size="18" fill="#9a3412">광고 그룹</text>
  <text x="455" y="124" font-family="Arial, sans-serif" font-size="14" fill="#7c2d12">두 단어가 자주 등장</text>
  <text x="455" y="148" font-family="Arial, sans-serif" font-size="16" fill="#7c2d12">점수 0.09</text>
  <text x="455" y="172" font-family="Arial, sans-serif" font-size="16" fill="#7c2d12">상대 점수 90%</text>
  <rect x="440" y="220" width="280" height="120" rx="12" fill="#ecfeff" stroke="#0891b2"/>
  <text x="455" y="248" font-family="Arial, sans-serif" font-size="18" fill="#164e63">일반 그룹</text>
  <text x="455" y="274" font-family="Arial, sans-serif" font-size="14" fill="#0e7490">두 단어가 드물게 등장</text>
  <text x="455" y="298" font-family="Arial, sans-serif" font-size="16" fill="#0e7490">점수 0.01</text>
  <text x="455" y="322" font-family="Arial, sans-serif" font-size="16" fill="#0e7490">상대 점수 10%</text>
  <rect x="30" y="240" width="360" height="100" rx="12" fill="#dcfce7" stroke="#16a34a"/>
  <text x="50" y="278" font-family="Arial, sans-serif" font-size="18" fill="#166534">예측한 그룹은 광고</text>
  <text x="50" y="305" font-family="Arial, sans-serif" font-size="16" fill="#166534">광고 점수가 더 높아요.</text>
</svg>
