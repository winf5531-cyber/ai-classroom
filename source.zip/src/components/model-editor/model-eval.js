import { LitElement, html, nothing as htmlNothing } from 'lit';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { ContextConsumer } from '@lit/context';
import { modelContext, dataTypeContext, encodingContext } from '../../contexts.js';
import { collectExample } from '../../services/lml-algorithms-bridge.js';

export class ModelEval extends LitElement {

  _dataTypeConsumer = new ContextConsumer(this, { context: dataTypeContext, subscribe: true });
  _encodingConsumer = new ContextConsumer(this, { context: encodingContext, subscribe: true });
  _modelConsumer = new ContextConsumer(this, { context: modelContext, subscribe: true });

  static properties = {
    imageSrc: { type: String },
    cameraOpened: { type: Boolean },
    results: { type: Array },
    advancedMode: { type: Object, attribute: 'advanced-mode' }
  }

  constructor() {
    super();
    this.imageSrc = null;
    this.cameraOpened = false;
    this.results = [];
    updateWhenLocaleChanges(this);

    this.bc = new BroadcastChannel('lml-internal');
    this.bc.addEventListener('message', message => {
      if (message.data == 'requestUpdate') {
        this.requestUpdate();
      }
    });
  }

  async checkInput() {
    this.results = [];
    const model = this._modelConsumer.value;
    if (!model?.model && !model?.isTrained) {
      alert(msg('You must generate a model before trying to classify'));
      return;
    }
    const text = this.querySelector('#textInput').value.trim();
    if (!text) {
      alert(msg('Enter a sentence to classify.', { id: 'predict-empty' }));
      return;
    }
    let features;
    try {
      features = await this._encodingConsumer.value.text([text]);
      if (!(await features.data()).some(value => value !== 0)) {
        alert(msg('No features overlap with the training examples.', { id: 'predict-unknown' }));
        return;
      }
      this.results = await model.classify(features);
    } catch {
      alert(msg('Could not classify this input.', { id: 'prediction-failed' }));
    } finally {
      features?.dispose();
    }
  }

  checkImage(image) {

    const model = this._modelConsumer.value;

    if (!model?.model && !model?.isTrained) {
      alert(msg('You must generate a model before trying to classify'));
      return;
    }

    let encode = this._encodingConsumer.value.image;
    encode([image]).then(features => {
      return this._modelConsumer.value.classify(features);
    }).then(results => {

      this.results = results;
    }).catch(error => {
      alert(msg('Could not classify this input.', { id: 'prediction-failed' }));
    })
  }

  checkNumber() {
    const model = this._modelConsumer.value;
    if (!model?.model && !model?.isTrained) {
      alert(msg('You must generate a model before trying to classify'));
      return;
    }

    let that = this;
    function isValidNumberEntry(entry) {
      let items = entry.split(",").map(v => parseFloat(v));;

      // primero miramos que todas los items separados por coma sean números
      if (items.some(item => isNaN(item))) return false;

      // comprobamos que la dimensión del array items coincida con this.dimension
      if (that._dataTypeConsumer.value.dimension != items.length) return false;

      // si hemos llegado hasta aquí, todo está bien
      return true;
    }
    let textToEncode = this.querySelector("#numberInput").value;

    if (!isValidNumberEntry(textToEncode)) {
      window.alert(msg("This entry is not valid"));
      return;
    }

    let encode = this._encodingConsumer.value.numerical;
    encode([textToEncode]).then(features => {
      return this._modelConsumer.value.classify(features);
    }).then(results => {

      this.results = results;
    }).catch(error => {
      alert(msg('Could not classify this input.', { id: 'prediction-failed' }));
    })

  }

  _uploadImage() {
    this.querySelector('#evalImageFileInput')?.click();
  }

  onLoaded(event) {
    // Obtener el archivo seleccionado (solo el primero en caso de múltiples archivos)
    const file = event.target.files[0];

    // Verificar si se seleccionó un archivo
    if (!file) {
      console.error("No se seleccionó ninguna imagen.");
      return;
    }

    // Crear una instancia de FileReader para leer el archivo
    const reader = new FileReader();

    // Definir el evento de carga para el lector de archivos
    reader.onload = () => {
      // Obtener el resultado en formato Base64
      const imageInBase64 = reader.result;

      // Imprimir o usar la imagen en Base64 según sea necesario
      this.imageSrc = imageInBase64;
      this.requestUpdate();
      this.checkImage(imageInBase64);
    };

    // Leer el archivo como Data URL (Base64)
    reader.readAsDataURL(file);
  }


  async openCamera() {
    this.video = this.querySelector("#video");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (!this.isConnected) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }
      this.stream = stream;
      this.video.srcObject = stream;
      this.cameraOpened = true;
    } catch {
      window.alert(msg("Can't init camera. Are you using it in another application?"));
    }
  }

  closeCamera() {
    this.cameraOpened = false;
    this.stream?.getTracks().forEach(track => {
      track.stop();
    })
    this.stream = null;
  }

  disconnectedCallback() {
    this.closeCamera();
    this.bc?.close();
    super.disconnectedCallback();
  }

  takePictureFromCamera() {
    this.cameraOpened = true;

    if (this.stream) {
      const canvas = document.createElement('canvas');
      canvas.width = this.video.width;
      canvas.height = this.video.height;
      const context = canvas.getContext('2d');

      // Dibujar el fotograma actual en el lienzo
      context.drawImage(this.video, 0, 0, canvas.width, canvas.height);

      // Obtener el contenido del lienzo como datos base64
      const base64String = canvas.toDataURL('image/png');
      this.imageSrc = base64String;

      this.checkImage(base64String);

      //this.closeCamera();
      this.requestUpdate();
    }
  }

  async startRecording() {
    const button = this.querySelector('#recordButton');
    const model = this._modelConsumer.value;
    if (!model?.model && !model?.isTrained) {
      alert(msg('You must generate a model before trying to classify'));
      return;
    }
    button.disabled = true;
    try {
      const sample = await collectExample("test");
      const features = await this._encodingConsumer.value.audio([sample]);
      this.results = await model.classify(features);
    } catch {
      alert(msg('Check microphone access and the network connection.', { id: 'microphone-error' }));
    } finally {
      button.disabled = false;
    }
  }

  templateTextEval() {
    return html`
    <h6 class="subtitle is-6">${msg("Introduces new terms and checks they are correctly classified ")}</h6>
    <textarea id="textInput" class="textarea"></textarea>
    
    <div class="field mt-2 is-grouped is-justify-content-center">
      <p class="control">
        <button @click=${this.checkInput} class="button is-primary">
          ${msg("Check")}
        </button>
      </p>            
    </div>`;
  }

  templateImageEval() {
    return html`
    <p class="mb-2">${msg("Allow camera access to take a photo on this device, or upload an image.", { id: "camera-purpose" })}</p>
    <input 
      id="evalImageFileInput" 
      accept="image/png, image/jpeg, image/webp, image/svg+xml"
      hidden="true" 
      type="file"
      @change=${this.onLoaded} >
    <h6 class="subtitle is-6">${msg("Introduces new images and checks they are correctly classified")}</h6> 
    <hr/>
    <div class="field is-grouped">
    ${!this.cameraOpened
        ? html`
        <p class="control">      
          <button @click=${this._uploadImage} class="button mr-1 is-primary is-fullwidth">
            <span class="icon">
            <i class="fas fa-images"></i>
            </span>
            <span>${msg('Upload images')}</span>
          </button>
        </p>
        <p class="control"> 
          <button @click=${this.openCamera} class="button mr-1 is-primary is-fullwidth">
            <span class="icon">
            <i class="fas fa-camera"></i>
            </span>
            <span>${msg('Take from camera')}</span>
          </button>
        </p>`

        : html`
        <p class="control"> 
          <button @click=${this.takePictureFromCamera} class="button mr-1 is-primary is-fullwidth">
            <span class="icon">
              <i class="fas fa-camera"></i>
            </span>
            <span>${msg('Take picture')}</span>
          </button>
        </p>
        <p class="control"> 
          <button @click=${this.closeCamera} class="button mr-1 is-primary is-fullwidth">
            <span class="icon">
              <i class="fas fa-xmark"></i>
            </span>
            <span>${msg('Close camera')}</span>
          </button>
        </p>`

      }
    </div>
  
    
    <div class="card-image has-text-centered">
      <video id="video" ?hidden=${!this.cameraOpened} width="320px" height="240px" autoplay></video>
    </div>
    <div class="card-image has-text-centered">
      <img ?hidden=${this.cameraOpened} alt="" width="300" src=${this.imageSrc || htmlNothing} />
    </div>
    `;
  }

  templateNumberEval() {
    return html`
    <h6 class="subtitle is-6">${msg("Introduces new numbers and checks they are correctly classified ")}</h6>
    <hr/>
    <input class="input" type="text" placeholder="1, 2, 3" id="numberInput" />
    
    <div class="field mt-2 is-grouped is-justify-content-center">
      <p class="control">
        <button @click=${this.checkNumber} class="button is-primary">
          ${msg("Check")}
        </button>
      </p>
    </div>`;
  }


  templateAudioEval() {
    return html`
    <h6 class="subtitle is-6">${msg("Introduce new sound and checks they are correctly classified ")}</h6>
    <hr/>    
    
    <div class="field mt-2 is-grouped is-justify-content-center">
      <p class="control">
        <button id="recordButton" @click=${this.startRecording} class="button is-primary">
          ${msg("Record")}
        </button>
      </p>
    </div>`;
  }

  templateFormEval(editorType) {
    switch (editorType) {
      case 'pose':
        return html`<p class="subtitle is-6">${msg('Try a new pose after training.', {id:'pose-test-hint'})}</p>
          <pose-input testing @pose-sample=${this.checkPose}></pose-input>`;
      case 'text':
        return this.templateTextEval();
      case 'image':
        return this.templateImageEval();
      case 'numerical':
        return this.templateNumberEval();
      case 'audio':
        return this.templateAudioEval();
    }
  }

  async checkPose(event) {
    const request = this.poseRequest = Symbol();
    const model = this._modelConsumer.value;
    this.results = [];
    if (!model?.model && !model?.isTrained) {
      alert(msg('You must generate a model before trying to classify'));
      return;
    }
    let features;
    try {
      features = await this._encodingConsumer.value.pose([event.detail]);
      const scores = await model.classify(features);
      if (request === this.poseRequest && model === this._modelConsumer.value) this.results = scores;
    } catch {
      alert(msg('Could not classify this input.', { id: 'prediction-failed' }));
    } finally {
      features?.dispose();
    }
  }

  resultScores() {
    if (!this.results.length) return htmlNothing;
    return html`<section aria-live="polite" class="mt-4">
      <h5 class="subtitle is-6">${msg("Class prediction scores (out of 100)", { id: "score-label" })}</h5>
      ${this.results.map(([label, value]) => html`<div>
        <strong>${label}</strong> ${Number((100 * value).toFixed(2))}
        <progress class="progress is-primary" aria-label=${label} value=${value} max="1"></progress>
      </div>`)}
    </section>`;
  }

  templateAdvanced() {
    return html`

<div class="columns">
    <div class="column">
      <h4 ?hidden="${this.advancedMode}" class="title is-4" > ${msg('Try')}</h4 >
      ${this.templateFormEval(this._dataTypeConsumer.value.type)}
    </div>
    <div class="column">
      ${this.resultScores()}  
    </div>
</div>

      
    `;
  }

  templateBasic() {
    return html`
<h4 class="title is-4" > ${msg('Try')}</h4 >
${this.templateFormEval(this._dataTypeConsumer.value.type)}

  ${this.resultScores()} 
`
  }

  render() {
    return html`
    ${this.advancedMode.enabled ?
        this.templateAdvanced()
        :
        this.templateBasic()}

      `
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    const initShadow = globalThis.__lmlInitShadowRoot;
    if (typeof initShadow === 'function') {
      initShadow(this, root);
    }
    return root;
  }
}

window.customElements.define('model-eval', ModelEval);
