import { LitElement, html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { msg, updateWhenLocaleChanges } from '@lit/localize';
import { ContextConsumer } from '@lit/context';
import { datasetContext, dataTypeContext } from '../../contexts.js';
import './dataset-manager.js';


export class ModelTrain extends LitElement {

  _datasetConsumer = new ContextConsumer(this, { context: datasetContext, subscribe: true });
  _dataTypeConsumer = new ContextConsumer(this, { context: dataTypeContext, subscribe: true });


  static properties = {
    dataset: { type: Set },
    advancedMode: { type: Object, attribute: 'advanced-mode' }
  }

  constructor() {
    super();
    updateWhenLocaleChanges(this);
  }

  connectedCallback() {
    super.connectedCallback();
    this.addEventListener('remove-label', () => this.requestUpdate());

  }

  addNewLabel() {
    let labelName = this.querySelector("#inputLabelName").value.trim();
    if (!labelName || this._datasetConsumer.value.has(labelName)) {
      alert(msg('Enter a new class name.', { id: 'class-name-error' }));
      return;
    }
    this._datasetConsumer.value.set(labelName, new Set());
    this.requestUpdate();
    this.querySelector("#inputLabelName").value = "";
    this.querySelector("#inputLabelName").focus();

  }

  trainingText(editorType) {
    switch (editorType) {
      case 'text':
        return msg('first I need some example texts');
      case 'image':
        return msg('First I need some sample images');
      case 'numerical':
        return msg('first I need some example vectors');
      case 'audio':
        return msg('first I need some sound samples');
    }
    return "";
  }


  render() {

    let datasetReversed = Array.from(this._datasetConsumer.value).slice().reverse();

    return html`

    <h4 ?hidden="${this.advancedMode}" class="title is-4">${msg('Training')}</h4>

    <h6 class="subtitle is-6">${this.trainingText(this._dataTypeConsumer.value.type)}</h6>
    <hr/>
    <div class="field has-addons">
      <div class="control">
        <input id="inputLabelName" @keydown=${e => { if (e.key === "Enter" && !e.isComposing) this.addNewLabel(); }} class="input" type="text" placeholder="${msg('New class name')}">
      </div>
      <div class="control">
        <button @click=${this.addNewLabel} class="button is-primary is-fullwidth mb-4">
          <span class="icon">
          <i class="fas fa-plus"></i>
          </span>
          <span>${msg('Add new class')}</span>
        </button>
      </div>
    </div>

    <div class="grid is-col-min-12">
      ${repeat(datasetReversed,
      entry => entry[0],
      (entry, index) => html`<div class="cell"><dataset-manager labelName=${entry[0]}></dataset-manager></div>`
    )}
    </div>
    
    `
  }

  createRenderRoot() {
    const root = super.createRenderRoot();
    const initShadow = globalThis.__lmlInitShadowRoot;
    if (typeof initShadow === 'function') {
      initShadow(this, root);
    }
    return root;
  }
}

window.customElements.define('model-train', ModelTrain);
