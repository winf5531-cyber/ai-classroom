export const siteName = import.meta.env.VITE_SITE_NAME || 'AI 학습실';
export const upstreamUrl = 'https://github.com/LearningML-Education/lml-editor';
export const editionAuthor = '정윤혁';
export const contactEmail = 'winf5531@gmail.com';
export const poseModelCredit = 'Google MoveNet SinglePose Lightning (Apache 2.0)';
