export const siteName = import.meta.env.VITE_SITE_NAME || 'AI 학습실';
export const upstreamUrl = 'https://github.com/LearningML-Education/lml-editor';
