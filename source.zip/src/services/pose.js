// MoveNet body landmarks, starting at its left shoulder (index 5).
// Each saved example contains twelve (x,y) pairs. A missing joint is (-1,-1).
export const poseEdges = [[0,1],[0,2],[2,4],[1,3],[3,5],[0,6],[1,7],[6,7],[6,8],[7,9],[8,10],[9,11]];

export function bodyPoints(output) {
  const points = [];
  for (let i = 5; i < 17; i++) {
    const [y, x, confidence] = output.slice(i * 3, i * 3 + 3);
    points.push(confidence >= 0.3 ? [x, y] : null);
  }
  return points;
}

export function poseVector(points) {
  const visible = points.filter(Boolean);
  if (visible.length < 4 || !(points[0] && points[1] || points[6] && points[7])) return null;
  const xs = visible.map(([x]) => x);
  const ys = visible.map(([, y]) => y);
  const left = Math.min(...xs);
  const top = Math.min(...ys);
  const span = Math.max(Math.max(...xs) - left, Math.max(...ys) - top);
  if (span < 0.05) return null;
  return points.flatMap(point => point
    ? [(point[0] - left) / span, (point[1] - top) / span].map(n => n.toFixed(4))
    : ['-1', '-1']).join(',');
}

export function parsePose(entry) {
  const values = entry.split(',').map(value => value.trim() ? Number(value) : NaN);
  if (values.length !== 24) throw new Error('Invalid pose length');
  const points = [];
  for (let i = 0; i < values.length; i += 2) {
    const pair = values.slice(i, i + 2);
    if (pair.every(n => n === -1)) points.push(null);
    else if (pair.every(n => Number.isFinite(n) && n >= 0 && n <= 1)) points.push(pair);
    else throw new Error('Invalid pose coordinates');
  }
  if (!poseVector(points)) throw new Error('Incomplete pose');
  return points;
}
