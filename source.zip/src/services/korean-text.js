// Upstream's ASCII tokenizer is still used for projects without Korean training text.
const hangul = /\p{Script=Hangul}/u;
const featurePrefix = 'ko:';

export const containsHangul = text => hangul.test(text);
export const isKoreanVocabulary = vocabulary =>
  vocabulary?.some(term => term.startsWith(featurePrefix)) ?? false;

export function koreanTextFeatures(text) {
  // Preserve the upstream lowercase/ASCII bag of words for other scripts in mixed projects.
  const tokens = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(Boolean);
  if (!containsHangul(text)) return tokens;

  // An example remains one sample. Punctuation and newlines end a run, so character
  // sequences can span optional spaces but never cross a sentence boundary.
  const runs = text.normalize('NFC').match(/\p{Script=Hangul}+(?:[ \t]+\p{Script=Hangul}+)*/gu) ?? [];
  for (const run of runs) {
    const words = run.split(/[ \t]+/);
    for (const word of words) tokens.push(featurePrefix + 'w:' + word);

    const syllables = Array.from(words.join(''));
    for (let i = 0; i < syllables.length - 1; i++) {
      tokens.push(featurePrefix + 'g:' + syllables[i] + syllables[i + 1]);
      if (i + 2 < syllables.length) {
        tokens.push(featurePrefix + 'g:' + syllables[i] + syllables[i + 1] + syllables[i + 2]);
      }
    }
  }
  return tokens;
}

export function buildKoreanVocabulary(texts) {
  const vocabulary = new Set();
  for (const text of texts) {
    for (const term of koreanTextFeatures(text)) vocabulary.add(term);
  }
  return Array.from(vocabulary);
}

export function koreanBagOfWords(text, vocabularyIndex) {
  const vector = new Float32Array(vocabularyIndex.size);
  for (const term of koreanTextFeatures(text)) {
    const column = vocabularyIndex.get(term);
    if (column !== undefined) vector[column]++;
  }
  return vector;
}
