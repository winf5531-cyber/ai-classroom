import * as tf from '@tensorflow/tfjs';
import { assetUrl } from '../utils/assetPaths.js';
import { bodyPoints } from './pose.js';

let loading;
export async function detectPose(canvas) {
  loading ??= tf.loadGraphModel(assetUrl('models/movenet-lightning/model.json')).catch(error => {
    loading = undefined;
    throw error;
  });
  const model = await loading;
  const output = tf.tidy(() => model.execute(tf.browser.fromPixels(canvas).expandDims(0)));
  try {
    return bodyPoints(await output.data());
  } finally {
    output.dispose();
  }
}
